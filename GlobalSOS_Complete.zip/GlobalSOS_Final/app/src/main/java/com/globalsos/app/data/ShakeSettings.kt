package com.globalsos.app.data

import android.content.Context
import android.content.SharedPreferences

data class ShakeSettings(
    val enabled: Boolean = false,
    val shakesNeeded: Int = 3,
    val detectionWindowMs: Long = 2000L,
    val maxAlerts: Int = 3,          // 0 = unlimited
    val sensitivity: Int = 15,       // lower = more sensitive (threshold in m/s²)
    val cooldownSecs: Int = 10,
    val messageType: String = "default", // "default", "custom", "both"
    val customMessage: String = "",
    val sirenEnabled: Boolean = true,
    val reoccurEnabled: Boolean = false,
    val reoccurMaxCount: Int = 3,    // 0 = unlimited
    val reoccurGapSecs: Long = 60L
)

class ShakeSettingsManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("shake_settings", Context.MODE_PRIVATE)

    fun save(s: ShakeSettings) {
        prefs.edit().apply {
            putBoolean("enabled", s.enabled)
            putInt("shakesNeeded", s.shakesNeeded)
            putLong("detectionWindowMs", s.detectionWindowMs)
            putInt("maxAlerts", s.maxAlerts)
            putInt("sensitivity", s.sensitivity)
            putInt("cooldownSecs", s.cooldownSecs)
            putString("messageType", s.messageType)
            putString("customMessage", s.customMessage)
            putBoolean("sirenEnabled", s.sirenEnabled)
            putBoolean("reoccurEnabled", s.reoccurEnabled)
            putInt("reoccurMaxCount", s.reoccurMaxCount)
            putLong("reoccurGapSecs", s.reoccurGapSecs)
            apply()
        }
    }

    fun load(): ShakeSettings = ShakeSettings(
        enabled = prefs.getBoolean("enabled", false),
        shakesNeeded = prefs.getInt("shakesNeeded", 3),
        detectionWindowMs = prefs.getLong("detectionWindowMs", 2000L),
        maxAlerts = prefs.getInt("maxAlerts", 3),
        sensitivity = prefs.getInt("sensitivity", 15),
        cooldownSecs = prefs.getInt("cooldownSecs", 10),
        messageType = prefs.getString("messageType", "default") ?: "default",
        customMessage = prefs.getString("customMessage", "") ?: "",
        sirenEnabled = prefs.getBoolean("sirenEnabled", true),
        reoccurEnabled = prefs.getBoolean("reoccurEnabled", false),
        reoccurMaxCount = prefs.getInt("reoccurMaxCount", 3),
        reoccurGapSecs = prefs.getLong("reoccurGapSecs", 60L)
    )
}
