package com.globalsos.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.*
import android.os.*
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import com.globalsos.app.R
import com.globalsos.app.data.ICEProfileManager
import com.globalsos.app.data.ShakeSettings
import com.globalsos.app.data.ShakeSettingsManager
import com.globalsos.app.ui.MainActivity
import com.google.android.gms.location.*

class ShakeDetectorService : Service(), SensorEventListener {

    companion object {
        const val ACTION_SHAKE_FIRED = "com.globalsos.app.SHAKE_FIRED"
        const val CHANNEL_ID = "ShakeSOS"
        const val NOTIF_ID = 2001

        fun start(context: Context) {
            val intent = Intent(context, ShakeDetectorService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ShakeDetectorService::class.java))
        }
    }

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private lateinit var shakeManager: ShakeSettingsManager
    private lateinit var iceManager: ICEProfileManager
    private lateinit var fusedLocation: FusedLocationProviderClient

    private var shakeCount = 0
    private var lastShakeTime = 0L
    private var lastCycleTime = 0L
    private var alertsSent = 0
    private var sirenTrack: AudioTrack? = null
    private var sirenThread: Thread? = null
    private var sirenActive = false
    private var currentLat: Double? = null
    private var currentLng: Double? = null

    // Re-occur
    private val reoccurHandler = Handler(Looper.getMainLooper())
    private var reoccurCount = 0

    override fun onCreate() {
        super.onCreate()
        shakeManager = ShakeSettingsManager(this)
        iceManager = ICEProfileManager(this)
        fusedLocation = LocationServices.getFusedLocationProviderClient(this)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        createNotifChannel()
        startForeground(NOTIF_ID, buildNotification())
        startLocationUpdates()
        registerShakeSensor()
    }

    private fun registerShakeSensor() {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    private fun startLocationUpdates() {
        try {
            val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10000L).build()
            fusedLocation.requestLocationUpdates(req, object : LocationCallback() {
                override fun onLocationResult(r: LocationResult) {
                    r.lastLocation?.let {
                        currentLat = it.latitude
                        currentLng = it.longitude
                    }
                }
            }, Looper.getMainLooper())
        } catch (e: SecurityException) { /* permission not granted */ }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        val e = event ?: return
        val s = shakeManager.load()
        if (!s.enabled) return

        val x = e.values[0]
        val y = e.values[1]
        val z = e.values[2]
        val magnitude = Math.sqrt((x * x + y * y + z * z).toDouble()).toFloat()
        val threshold = s.sensitivity.toFloat() // lower = more sensitive

        if (magnitude > threshold) {
            val now = System.currentTimeMillis()
            val cooldownMs = s.cooldownSecs * 1000L

            // Cooldown between cycles
            if (now - lastCycleTime < cooldownMs) return

            // Reset shake count if window exceeded
            if (now - lastShakeTime > s.detectionWindowMs) {
                shakeCount = 0
            }

            shakeCount++
            lastShakeTime = now

            if (shakeCount >= s.shakesNeeded) {
                shakeCount = 0
                if (alertsSent < s.maxAlerts || s.maxAlerts == 0) {
                    lastCycleTime = now
                    alertsSent++
                    triggerShakeSOS(s)
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun triggerShakeSOS(s: ShakeSettings) {
        // Build message
        val profile = iceManager.load()
        val name = profile.fullName.ifBlank { "Unknown" }
        var msg = buildMessage(s, name)

        // Add GPS
        if (currentLat != null && currentLng != null) {
            msg += "\n\n📍 GPS: https://www.google.com/maps?q=$currentLat,$currentLng\n($currentLat, $currentLng)"
        } else {
            msg += "\n\n📍 GPS: Unavailable"
        }

        // Send SMS to ICE contacts
        val contacts = iceManager.getEmergencyContacts()
        contacts.forEach { (_, phone) ->
            try {
                val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION") SmsManager.getDefault()
                }
                val parts = smsManager.divideMessage(msg)
                smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
            } catch (e: Exception) {
                // Fallback
            }
        }

        // Siren
        if (s.sirenEnabled) startSiren()

        // Broadcast
        sendBroadcast(Intent(ACTION_SHAKE_FIRED))

        // Update notification
        updateNotification("🚨 Shake SOS Fired! #$alertsSent")

        // Re-occur
        if (s.reoccurEnabled) {
            scheduleReoccur(s)
        }
    }

    private fun buildMessage(s: ShakeSettings, name: String): String {
        val ts = java.text.SimpleDateFormat("HH:mm dd/MM/yyyy", java.util.Locale.getDefault())
            .format(java.util.Date())
        val defaultMsg = "🚨 SHAKE SOS ALERT 🚨\n$name needs URGENT help!\n\nTime: $ts\n\nSent by Global SOS — Shake Trigger"
        return when (s.messageType) {
            "custom" -> if (s.customMessage.isNotBlank()) s.customMessage else defaultMsg
            "both" -> defaultMsg + if (s.customMessage.isNotBlank()) "\n\n${s.customMessage}" else ""
            else -> defaultMsg
        }
    }

    private fun scheduleReoccur(s: ShakeSettings) {
        if (s.reoccurMaxCount > 0 && reoccurCount >= s.reoccurMaxCount) return
        reoccurHandler.postDelayed({
            val current = shakeManager.load()
            if (current.enabled) {
                reoccurCount++
                alertsSent++
                triggerShakeSOS(current)
            }
        }, s.reoccurGapSecs * 1000L)
    }

    private fun startSiren() {
        if (sirenActive) return
        sirenActive = true
        sirenThread = Thread {
            val sampleRate = 44100
            val bufferSize = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            sirenTrack = AudioTrack(AudioManager.STREAM_ALARM, sampleRate, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, bufferSize, AudioTrack.MODE_STREAM)
            sirenTrack?.play()
            val buffer = ShortArray(bufferSize)
            var phase = 0.0; var freq = 450.0; var goingUp = true
            var elapsed = 0; val maxMs = 10000
            while (sirenActive && elapsed < maxMs) {
                for (i in buffer.indices) {
                    buffer[i] = (Short.MAX_VALUE * Math.sin(phase)).toInt().toShort()
                    phase += 2.0 * Math.PI * freq / sampleRate
                }
                sirenTrack?.write(buffer, 0, buffer.size)
                if (goingUp) { freq += 5.0; if (freq >= 1300) goingUp = false }
                else { freq -= 5.0; if (freq <= 450) goingUp = true }
                elapsed += (bufferSize * 1000 / sampleRate)
            }
            sirenActive = false
            sirenTrack?.apply { stop(); release() }
            sirenTrack = null
        }.also { it.start() }
    }

    private fun createNotifChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Shake SOS Monitor", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String = "📳 Shake SOS active — Shake to trigger"): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_sos_notification)
            .setContentTitle("Shake SOS Running")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        sensorManager.unregisterListener(this)
        sirenActive = false
        sirenThread?.interrupt()
        sirenTrack?.apply { try { stop(); release() } catch (e: Exception) {} }
        reoccurHandler.removeCallbacksAndMessages(null)
    }

    override fun onBind(intent: Intent?) = null
}
