package com.globalsos.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class GlobalSOSApp : Application() {

    companion object {
        const val CHANNEL_SOS_MONITOR = "sos_monitor_channel"
        const val CHANNEL_SOS_ALERT = "sos_alert_channel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val monitorChannel = NotificationChannel(
                CHANNEL_SOS_MONITOR,
                "SOS Monitor Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Persistent notification for Auto SOS monitoring"
            }

            val alertChannel = NotificationChannel(
                CHANNEL_SOS_ALERT,
                "SOS Alert",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Triggered when Auto SOS fires"
            }

            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(monitorChannel)
            nm.createNotificationChannel(alertChannel)
        }
    }
}
