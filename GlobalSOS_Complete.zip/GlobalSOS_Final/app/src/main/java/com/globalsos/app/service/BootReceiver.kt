package com.globalsos.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.globalsos.app.data.AutoSOSSettingsManager
import com.globalsos.app.data.ShakeSettingsManager

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED && context != null) {
            // Restart Auto SOS if was running
            val autoSettings = AutoSOSSettingsManager(context)
            if (autoSettings.isMonitorRunning()) {
                SOSMonitorService.start(context)
            }
            // Restart Shake SOS if was enabled
            val shakeSettings = ShakeSettingsManager(context)
            if (shakeSettings.load().enabled) {
                ShakeDetectorService.start(context)
            }
        }
    }
}
