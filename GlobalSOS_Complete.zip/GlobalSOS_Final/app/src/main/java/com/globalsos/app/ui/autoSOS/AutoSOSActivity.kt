package com.globalsos.app.ui.autoSOS

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.globalsos.app.R
import com.globalsos.app.data.AutoSOSSettings
import com.globalsos.app.data.AutoSOSSettingsManager
import com.globalsos.app.data.ICEProfileManager
import com.globalsos.app.service.SOSMonitorService

class AutoSOSActivity : AppCompatActivity() {

    private lateinit var settingsManager: AutoSOSSettingsManager
    private lateinit var iceManager: ICEProfileManager

    private lateinit var swBattery: Switch
    private lateinit var sbBatteryThreshold: SeekBar
    private lateinit var tvBatteryThreshold: TextView
    private lateinit var spBatteryDelay: Spinner
    private lateinit var swInactivity: Switch
    private lateinit var spInactivity: Spinner
    private lateinit var swSiren: Switch
    private lateinit var rgMessage: RadioGroup
    private lateinit var rbDefault: RadioButton
    private lateinit var rbCustom: RadioButton
    private lateinit var etCustomMsg: EditText
    private lateinit var tvStatus: TextView
    private lateinit var btnMaster: Button
    private lateinit var tvPinStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auto_sos)

        settingsManager = AutoSOSSettingsManager(this)
        iceManager = ICEProfileManager(this)

        initViews()
        loadSettings()

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
    }

    private fun initViews() {
        swBattery = findViewById(R.id.swBattery)
        sbBatteryThreshold = findViewById(R.id.sbBatteryThreshold)
        tvBatteryThreshold = findViewById(R.id.tvBatteryThreshold)
        spBatteryDelay = findViewById(R.id.spBatteryDelay)
        swInactivity = findViewById(R.id.swInactivity)
        spInactivity = findViewById(R.id.spInactivity)
        swSiren = findViewById(R.id.swSiren)
        rgMessage = findViewById(R.id.rgMessage)
        rbDefault = findViewById(R.id.rbDefault)
        rbCustom = findViewById(R.id.rbCustom)
        etCustomMsg = findViewById(R.id.etCustomMsg)
        tvStatus = findViewById(R.id.tvStatus)
        btnMaster = findViewById(R.id.btnMaster)
        tvPinStatus = findViewById(R.id.tvPinStatus)

        // Battery threshold slider
        sbBatteryThreshold.max = 40
        sbBatteryThreshold.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val threshold = progress + 5
                tvBatteryThreshold.text = "Battery Threshold: ${threshold}%"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Battery delay spinner
        val delays = arrayOf("Immediate", "5 Mins Idle", "10 Mins Idle", "30 Mins Idle", "1 Hour Idle", "3 Hours Idle")
        spBatteryDelay.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, delays)

        // Inactivity spinner
        val inactivities = arrayOf("5 Minutes","15 Minutes","30 Minutes","1 Hour","3 Hours","6 Hours","12 Hours","24 Hours","48 Hours")
        spInactivity.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, inactivities)

        // Custom message toggle
        rbCustom.setOnCheckedChangeListener { _, checked ->
            etCustomMsg.isEnabled = checked
        }

        // Master button
        btnMaster.setOnClickListener {
            val settings = settingsManager.load()
            if (settings.isMonitorRunning) {
                stopMonitor()
            } else {
                startMonitor()
            }
        }
    }

    private fun loadSettings() {
        val s = settingsManager.load()
        swBattery.isChecked = s.batteryEnabled
        sbBatteryThreshold.progress = (s.batteryThreshold - 5).coerceAtLeast(0)
        tvBatteryThreshold.text = "Battery Threshold: ${s.batteryThreshold}%"
        swInactivity.isChecked = s.inactivityEnabled
        swSiren.isChecked = s.sirenEnabled

        val delayIndex = when(s.batteryDelayMins) {
            0 -> 0; 5 -> 1; 10 -> 2; 30 -> 3; 60 -> 4; else -> 5
        }
        spBatteryDelay.setSelection(delayIndex)

        val idleIndex = when {
            s.inactivityMins <= 5 -> 0; s.inactivityMins <= 15 -> 1; s.inactivityMins <= 30 -> 2
            s.inactivityMins <= 60 -> 3; s.inactivityMins <= 180 -> 4; s.inactivityMins <= 360 -> 5
            s.inactivityMins <= 720 -> 6; s.inactivityMins <= 1440 -> 7; else -> 8
        }
        spInactivity.setSelection(idleIndex)

        if (s.messageType == "custom") rbCustom.isChecked = true else rbDefault.isChecked = true
        etCustomMsg.setText(s.customMessage)

        updateUI(s.isMonitorRunning)
    }

    private fun saveCurrentSettings(): AutoSOSSettings {
        val delayMins = when(spBatteryDelay.selectedItemPosition) {
            0 -> 0; 1 -> 5; 2 -> 10; 3 -> 30; 4 -> 60; else -> 180
        }
        val idleMins = when(spInactivity.selectedItemPosition) {
            0 -> 5; 1 -> 15; 2 -> 30; 3 -> 60; 4 -> 180; 5 -> 360; 6 -> 720; 7 -> 1440; else -> 2880
        }
        val current = settingsManager.load()
        return AutoSOSSettings(
            batteryEnabled = swBattery.isChecked,
            batteryThreshold = sbBatteryThreshold.progress + 5,
            batteryDelayMins = delayMins,
            inactivityEnabled = swInactivity.isChecked,
            inactivityMins = idleMins,
            sirenEnabled = swSiren.isChecked,
            messageType = if (rbCustom.isChecked) "custom" else "default",
            customMessage = etCustomMsg.text.toString(),
            pin = current.pin,
            isMonitorRunning = current.isMonitorRunning,
            monitorStartTime = current.monitorStartTime
        )
    }

    private fun startMonitor() {
        // Validate contacts
        if (!iceManager.hasContacts()) {
            AlertDialog.Builder(this)
                .setTitle("⚠️ No Emergency Contacts")
                .setMessage("Please add at least one emergency contact in your ICE Card before starting the monitor.")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        // Validate at least one trigger
        if (!swBattery.isChecked && !swInactivity.isChecked) {
            AlertDialog.Builder(this)
                .setTitle("⚠️ No Triggers Enabled")
                .setMessage("Please enable at least one trigger (Battery or Inactivity).")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        // Request permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS permission required for Auto SOS", Toast.LENGTH_LONG).show()
        }

        // Create PIN
        showCreatePinDialog { pin ->
            val settings = saveCurrentSettings()
            settingsManager.save(settings.copy(pin = pin, isMonitorRunning = true, monitorStartTime = System.currentTimeMillis()))
            SOSMonitorService.start(this)
            updateUI(true)
            Toast.makeText(this, "✅ SOS Monitor Started!\nMinimize app — monitoring continues.", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopMonitor() {
        val pin = settingsManager.load().pin
        if (pin.isNotBlank()) {
            showVerifyPinDialog(pin) {
                doStopMonitor()
            }
        } else {
            doStopMonitor()
        }
    }

    private fun doStopMonitor() {
        SOSMonitorService.stop(this)
        settingsManager.setMonitorRunning(false)
        updateUI(false)
        Toast.makeText(this, "✅ Monitor Stopped", Toast.LENGTH_SHORT).show()
    }

    private fun updateUI(running: Boolean) {
        if (running) {
            tvStatus.text = "🟢 MONITORING ACTIVE"
            tvStatus.setTextColor(getColor(R.color.accent_green))
            btnMaster.text = "🛑 STOP MONITORING"
            btnMaster.setBackgroundColor(getColor(R.color.accent_red))
            lockSettings(true)
        } else {
            tvStatus.text = "🔴 MONITOR OFF"
            tvStatus.setTextColor(getColor(R.color.accent_red))
            btnMaster.text = "▶ START MONITORING"
            btnMaster.setBackgroundColor(getColor(R.color.accent_green))
            lockSettings(false)
        }
    }

    private fun lockSettings(locked: Boolean) {
        listOf(swBattery, sbBatteryThreshold, spBatteryDelay, swInactivity, spInactivity,
            swSiren, rbDefault, rbCustom, etCustomMsg).forEach {
            it.isEnabled = !locked
        }
    }

    private fun showCreatePinDialog(onPinSet: (String) -> Unit) {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "Enter 4-digit PIN"
        }
        AlertDialog.Builder(this)
            .setTitle("🔐 Set Security PIN")
            .setMessage("Create a PIN to prevent accidental monitor stops.")
            .setView(input)
            .setPositiveButton("Set PIN") { _, _ ->
                val pin = input.text.toString()
                if (pin.length == 4) {
                    onPinSet(pin)
                } else {
                    onPinSet("") // Allow no PIN
                }
            }
            .setNegativeButton("Skip") { _, _ -> onPinSet("") }
            .show()
    }

    private fun showVerifyPinDialog(savedPin: String, onVerified: () -> Unit) {
        val input = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "Enter your PIN"
        }
        AlertDialog.Builder(this)
            .setTitle("🔐 Enter PIN to Stop")
            .setView(input)
            .setPositiveButton("Verify") { _, _ ->
                if (input.text.toString() == savedPin) {
                    onVerified()
                } else {
                    Toast.makeText(this, "❌ Wrong PIN", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
