package com.globalsos.app.ui.ice

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.globalsos.app.R
import com.globalsos.app.data.ICEProfile
import com.globalsos.app.data.ICEProfileManager
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.WriterException
import com.google.zxing.qrcode.QRCodeWriter

class ICECardActivity : AppCompatActivity() {

    private lateinit var iceManager: ICEProfileManager
    private var isLocked = false
    private var pendingContactSlot = 1

    private lateinit var etName: EditText
    private lateinit var etDob: EditText
    private lateinit var spBlood: Spinner
    private lateinit var etMedical: EditText
    private lateinit var etInsProvider: EditText
    private lateinit var etInsPolicy: EditText
    private lateinit var etContact1Name: EditText
    private lateinit var etContact1Phone: EditText
    private lateinit var etContact2Name: EditText
    private lateinit var etContact2Phone: EditText
    private lateinit var btnSave: Button
    private lateinit var btnLock: Button
    private lateinit var tvLockStatus: TextView
    private lateinit var ivQR: ImageView

    private val contactPickerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                result.data?.data?.let { uri ->
                    fillContactFromUri(uri, pendingContactSlot)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ice_card)

        iceManager = ICEProfileManager(this)

        initViews()
        loadData()
        setupLock()
        setupContactButtons()
        setupSave()
        generateQR()
    }

    private fun initViews() {
        etName = findViewById(R.id.etName)
        etDob = findViewById(R.id.etDob)
        spBlood = findViewById(R.id.spBloodType)
        etMedical = findViewById(R.id.etMedical)
        etInsProvider = findViewById(R.id.etInsProvider)
        etInsPolicy = findViewById(R.id.etInsPolicy)
        etContact1Name = findViewById(R.id.etContact1Name)
        etContact1Phone = findViewById(R.id.etContact1Phone)
        etContact2Name = findViewById(R.id.etContact2Name)
        etContact2Phone = findViewById(R.id.etContact2Phone)
        btnSave = findViewById(R.id.btnSave)
        btnLock = findViewById(R.id.btnLock)
        tvLockStatus = findViewById(R.id.tvLockStatus)
        ivQR = findViewById(R.id.ivQR)

        val bloodTypes = arrayOf("Unknown","A+","A-","B+","B-","O+","O-","AB+","AB-")
        spBlood.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, bloodTypes)

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        // Wallpaper download button
        findViewById<Button>(R.id.btnDownloadWallpaper).setOnClickListener {
            downloadQRWallpaper()
        }
    }

    private fun loadData() {
        val profile = iceManager.load()
        etName.setText(profile.fullName)
        etDob.setText(profile.dateOfBirth)
        etMedical.setText(profile.medicalNotes)
        etInsProvider.setText(profile.insuranceProvider)
        etInsPolicy.setText(profile.policyNumber)
        etContact1Name.setText(profile.contact1Name)
        etContact1Phone.setText(profile.contact1Phone)
        etContact2Name.setText(profile.contact2Name)
        etContact2Phone.setText(profile.contact2Phone)

        val btIndex = listOf("Unknown","A+","A-","B+","B-","O+","O-","AB+","AB-").indexOf(profile.bloodType)
        if (btIndex >= 0) spBlood.setSelection(btIndex)

        isLocked = iceManager.isLocked()
        applyLockState()
    }

    private fun setupLock() {
        btnLock.setOnClickListener {
            isLocked = !isLocked
            iceManager.setLocked(isLocked)
            applyLockState()
        }
    }

    private fun applyLockState() {
        val fields = listOf(etName, etDob, etMedical, etInsProvider, etInsPolicy,
            etContact1Name, etContact1Phone, etContact2Name, etContact2Phone)
        fields.forEach { it.isEnabled = !isLocked }
        spBlood.isEnabled = !isLocked
        btnSave.isEnabled = !isLocked

        if (isLocked) {
            btnLock.text = "🔓 UNLOCK TO EDIT"
            tvLockStatus.text = "🔒 LOCKED"
            tvLockStatus.setTextColor(getColor(R.color.accent_orange))
        } else {
            btnLock.text = "🔒 LOCK DATA"
            tvLockStatus.text = "🔓 UNLOCKED"
            tvLockStatus.setTextColor(getColor(R.color.accent_green))
        }
    }

    private fun setupContactButtons() {
        findViewById<Button>(R.id.btnImportContact1).setOnClickListener {
            pendingContactSlot = 1
            pickContact()
        }
        findViewById<Button>(R.id.btnImportContact2).setOnClickListener {
            pendingContactSlot = 2
            pickContact()
        }
        findViewById<Button>(R.id.btnCall1).setOnClickListener {
            val num = etContact1Phone.text.toString()
            if (num.isNotBlank()) startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))
        }
        findViewById<Button>(R.id.btnCall2).setOnClickListener {
            val num = etContact2Phone.text.toString()
            if (num.isNotBlank()) startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")))
        }
    }

    private fun pickContact() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Contact permission required", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
        contactPickerLauncher.launch(intent)
    }

    private fun fillContactFromUri(uri: Uri, slot: Int) {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val name = cursor.getString(nameIdx) ?: ""
                val number = cursor.getString(numIdx)?.replace(Regex("[^0-9+]"), "") ?: ""

                if (slot == 1) {
                    etContact1Name.setText(name)
                    etContact1Phone.setText(number)
                } else {
                    etContact2Name.setText(name)
                    etContact2Phone.setText(number)
                }
            }
        }
    }

    private fun setupSave() {
        btnSave.setOnClickListener {
            saveData()
        }
    }

    private fun saveData() {
        val profile = ICEProfile(
            fullName = etName.text.toString(),
            bloodType = spBlood.selectedItem.toString(),
            dateOfBirth = etDob.text.toString(),
            medicalNotes = etMedical.text.toString(),
            insuranceProvider = etInsProvider.text.toString(),
            policyNumber = etInsPolicy.text.toString(),
            contact1Name = etContact1Name.text.toString(),
            contact1Phone = etContact1Phone.text.toString().replace(Regex("[^0-9+]"), ""),
            contact2Name = etContact2Name.text.toString(),
            contact2Phone = etContact2Phone.text.toString().replace(Regex("[^0-9+]"), "")
        )
        iceManager.save(profile)
        Toast.makeText(this, "✅ ICE Card Saved!", Toast.LENGTH_SHORT).show()
        generateQR()
    }

    private fun generateQR() {
        val profile = iceManager.load()
        val qrContent = """
            EMERGENCY ICE CARD
            Name: ${profile.fullName}
            Blood Type: ${profile.bloodType}
            DOB: ${profile.dateOfBirth}
            Medical Notes: ${profile.medicalNotes}
            Insurance: ${profile.insuranceProvider} / ${profile.policyNumber}
            ICE Contact 1: ${profile.contact1Name} (${profile.contact1Phone})
            ICE Contact 2: ${profile.contact2Name} (${profile.contact2Phone})
        """.trimIndent()

        try {
            val hints = mapOf(EncodeHintType.CHARACTER_SET to "UTF-8")
            val writer = QRCodeWriter()
            val matrix = writer.encode(qrContent, BarcodeFormat.QR_CODE, 512, 512, hints)
            val bmp = Bitmap.createBitmap(512, 512, Bitmap.Config.RGB_565)
            for (x in 0 until 512) {
                for (y in 0 until 512) {
                    bmp.setPixel(x, y, if (matrix[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
                }
            }
            ivQR.setImageBitmap(bmp)
            lastQRBitmap = bmp
        } catch (e: WriterException) {
            e.printStackTrace()
        }
    }

    private var lastQRBitmap: Bitmap? = null

    fun downloadQRWallpaper() {
        val qrBmp = lastQRBitmap
        if (qrBmp == null) {
            Toast.makeText(this, "Please save ICE data first to generate QR code.", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            // Create wallpaper canvas (1080x2400 standard mobile size)
            val wallpaper = Bitmap.createBitmap(1080, 2400, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(wallpaper)

            // Black background
            canvas.drawColor(android.graphics.Color.BLACK)

            // Red banner
            val redPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.parseColor("#d32f2f")
                style = android.graphics.Paint.Style.FILL
            }
            canvas.drawRect(0f, 1250f, 1080f, 1370f, redPaint)

            // Banner text
            val bannerPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.WHITE
                textSize = 50f
                typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("IN CASE OF EMERGENCY", 540f, 1325f, bannerPaint)

            // Subtitle
            val subPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.parseColor("#ff6b6b")
                textSize = 36f
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("Scan QR Code for Medical Info", 540f, 1420f, subPaint)

            // White background for QR
            val qrSize = 380
            val qrX = (1080 - qrSize - 20) / 2f
            val qrY = 1470f
            val whitePaint = android.graphics.Paint().apply {
                color = android.graphics.Color.WHITE
                style = android.graphics.Paint.Style.FILL
            }
            canvas.drawRoundRect(qrX, qrY, qrX + qrSize + 20, qrY + qrSize + 20, 15f, 15f, whitePaint)

            // Draw QR code
            val scaledQR = Bitmap.createScaledBitmap(qrBmp, qrSize, qrSize, true)
            canvas.drawBitmap(scaledQR, qrX + 10, qrY + 10, null)

            // Instructions
            val instrPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.parseColor("#8e8e93")
                textSize = 30f
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
                typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            }
            canvas.drawText("📱 How to scan:", 540f, 1930f, instrPaint)

            val instrPaint2 = android.graphics.Paint().apply {
                color = android.graphics.Color.parseColor("#8e8e93")
                textSize = 28f
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("1. Open Camera App", 540f, 1980f, instrPaint2)
            canvas.drawText("2. Point at QR Code", 540f, 2020f, instrPaint2)
            canvas.drawText("3. Tap the pop-up link", 540f, 2060f, instrPaint2)

            // Branding
            val brandPaint = android.graphics.Paint().apply {
                color = android.graphics.Color.parseColor("#444444")
                textSize = 24f
                textAlign = android.graphics.Paint.Align.CENTER
                isAntiAlias = true
            }
            canvas.drawText("Global SOS - Set as Lock Screen Wallpaper", 540f, 2150f, brandPaint)

            // Save to gallery
            val filename = "GlobalSOS_Wallpaper_${System.currentTimeMillis()}.png"
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GlobalSOS")
                }
            }

            val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            uri?.let {
                contentResolver.openOutputStream(it)?.use { stream ->
                    wallpaper.compress(Bitmap.CompressFormat.PNG, 100, stream)
                }
            }

            AlertDialog.Builder(this)
                .setTitle("✅ Wallpaper Saved!")
                .setMessage("📱 To use:\n\n1. Open the saved image from Gallery\n2. Set as Lock Screen Wallpaper\n3. Anyone can scan QR from your lock screen to see your medical info!")
                .setPositiveButton("OK", null)
                .show()

        } catch (e: Exception) {
            Toast.makeText(this, "Error saving wallpaper: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
