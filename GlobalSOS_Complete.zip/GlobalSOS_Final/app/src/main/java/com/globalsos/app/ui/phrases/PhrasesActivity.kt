package com.globalsos.app.ui.phrases

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.globalsos.app.R
import java.util.Locale

data class PhraseCategory(val name: String, val phrases: List<EmergencyPhrase>)
data class EmergencyPhrase(val emoji: String, val text: String)

class PhrasesActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var llPhrases: LinearLayout
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val categories: List<PhraseCategory> = listOf(
        PhraseCategory("🏥 Medical Emergency", listOf(
            EmergencyPhrase("🆘","Help! I need medical assistance!"),
            EmergencyPhrase("🚑","Call an ambulance immediately!"),
            EmergencyPhrase("😵","Someone is unconscious!"),
            EmergencyPhrase("💔","I'm having chest pain!"),
            EmergencyPhrase("🫁","Someone is choking!"),
            EmergencyPhrase("🤒","High fever and difficulty breathing!"),
            EmergencyPhrase("💊","Allergic reaction - need EpiPen!"),
            EmergencyPhrase("🩸","Severe bleeding - need help!"),
            EmergencyPhrase("🦴","I think I have a broken bone!"),
            EmergencyPhrase("😱","I am having a panic attack!"),
            EmergencyPhrase("🩺","I am diabetic - I need sugar now!"),
            EmergencyPhrase("💉","I need insulin immediately!"),
            EmergencyPhrase("🫀","Someone is having a stroke!"),
            EmergencyPhrase("🤕","Head injury - person is confused!"),
            EmergencyPhrase("🩹","I have swallowed something dangerous!")
        )),
        PhraseCategory("🚔 Police Emergency", listOf(
            EmergencyPhrase("👮","Help! Call the police!"),
            EmergencyPhrase("🚨","There's an intruder!"),
            EmergencyPhrase("⚠️","I'm in danger!"),
            EmergencyPhrase("👣","Someone is following me!"),
            EmergencyPhrase("🚗","I witnessed an accident!"),
            EmergencyPhrase("🔫","I hear gunshots nearby!"),
            EmergencyPhrase("👊","Assault in progress!"),
            EmergencyPhrase("🏃","Robbery - call police now!"),
            EmergencyPhrase("🚪","Intruder in the building!"),
            EmergencyPhrase("📱","My phone / wallet was stolen!"),
            EmergencyPhrase("🔪","Person has a weapon!"),
            EmergencyPhrase("🚓","Please send police to this location!")
        )),
        PhraseCategory("🔥 Fire Emergency", listOf(
            EmergencyPhrase("🚒","Fire! Call the fire department!"),
            EmergencyPhrase("🏢","Building is on fire - evacuate now!"),
            EmergencyPhrase("💨","I smell smoke!"),
            EmergencyPhrase("⛽","Gas leak - evacuate immediately!"),
            EmergencyPhrase("🌲","Forest fire spreading quickly!"),
            EmergencyPhrase("⚡","Electrical fire - cut power!"),
            EmergencyPhrase("🧯","We need a fire extinguisher!"),
            EmergencyPhrase("🔥","The exit is blocked by fire!"),
            EmergencyPhrase("☠️","Carbon monoxide alarm is going off!")
        )),
        PhraseCategory("🆘 General Help", listOf(
            EmergencyPhrase("🙋","Help! I need assistance!"),
            EmergencyPhrase("🚨","Emergency! Please help!"),
            EmergencyPhrase("🗺️","I'm lost and need help!"),
            EmergencyPhrase("📍","My location is..."),
            EmergencyPhrase("📞","Please send help to this address!"),
            EmergencyPhrase("🏔️","Stranded - need rescue!"),
            EmergencyPhrase("🌊","Flood emergency!"),
            EmergencyPhrase("😰","I am scared - please stay with me!"),
            EmergencyPhrase("🔆","I need to signal for help!"),
            EmergencyPhrase("🆘","SOS - I am in an emergency!")
        )),
        PhraseCategory("🏠 Home Emergency", listOf(
            EmergencyPhrase("💧","Water leak - need emergency plumber!"),
            EmergencyPhrase("⚡","Power outage in the building!"),
            EmergencyPhrase("☠️","Carbon monoxide alarm is beeping!"),
            EmergencyPhrase("🛗","Elevator is stuck with people inside!"),
            EmergencyPhrase("🪟","Broken window - security issue!"),
            EmergencyPhrase("🚪","Locked out - need locksmith!"),
            EmergencyPhrase("💨","Gas smell - turn off mains!"),
            EmergencyPhrase("🔨","Structural damage to building!"),
            EmergencyPhrase("🐛","Pest emergency - swarm infestation!")
        )),
        PhraseCategory("🚗 Road Emergency", listOf(
            EmergencyPhrase("💥","Car accident - need help!"),
            EmergencyPhrase("🔧","Vehicle broken down on highway!"),
            EmergencyPhrase("🤕","Injured person on the road!"),
            EmergencyPhrase("🚙","Dangerous driver - please report!"),
            EmergencyPhrase("🛣️","Road blocked - debris on highway!"),
            EmergencyPhrase("🚦","Traffic lights not working!"),
            EmergencyPhrase("🏍️","Motorcyclist down on the road!"),
            EmergencyPhrase("🚛","Truck overturned - road closed!"),
            EmergencyPhrase("🔋","Car battery dead - need jump start!")
        )),
        PhraseCategory("⛈️ Weather Emergency", listOf(
            EmergencyPhrase("🌪️","Tornado warning - take shelter!"),
            EmergencyPhrase("🌊","Flash flood - evacuate immediately!"),
            EmergencyPhrase("⚡","Severe lightning storm!"),
            EmergencyPhrase("❄️","Blizzard - stranded and need help!"),
            EmergencyPhrase("🌀","Hurricane approaching!"),
            EmergencyPhrase("🏔️","Avalanche danger!"),
            EmergencyPhrase("🌋","Volcano eruption alert!"),
            EmergencyPhrase("🌡️","Extreme heat emergency!"),
            EmergencyPhrase("🏜️","Sandstorm approaching!")
        )),
        PhraseCategory("👶 Child Safety", listOf(
            EmergencyPhrase("👶","Child in danger!"),
            EmergencyPhrase("🏫","School emergency!"),
            EmergencyPhrase("🚸","Child missing - need help!"),
            EmergencyPhrase("👨‍👩‍👧","Child separated from parents!"),
            EmergencyPhrase("🩹","Child injured - need medical help!"),
            EmergencyPhrase("🆘","Child abuse emergency!"),
            EmergencyPhrase("😢","Child is distressed and won't talk!"),
            EmergencyPhrase("🚌","Child missing from school bus!"),
            EmergencyPhrase("🏃","Child being followed / chased!")
        )),
        PhraseCategory("🐕 Animal Emergency", listOf(
            EmergencyPhrase("🐕","Injured animal needs help!"),
            EmergencyPhrase("🐍","Dangerous animal spotted!"),
            EmergencyPhrase("🐻","Wild animal attack!"),
            EmergencyPhrase("🐶","Lost pet - please help find!"),
            EmergencyPhrase("🦮","Service animal in distress!"),
            EmergencyPhrase("🦁","Large predator loose!"),
            EmergencyPhrase("🐝","Bee / wasp swarm attack!"),
            EmergencyPhrase("🐊","Crocodile / alligator spotted nearby!")
        )),
        PhraseCategory("🌊 Water Emergency", listOf(
            EmergencyPhrase("🏊","Drowning! Need lifeguard!"),
            EmergencyPhrase("⛵","Boat sinking - send help!"),
            EmergencyPhrase("🌊","Person swept away by current!"),
            EmergencyPhrase("🏖️","Beach emergency!"),
            EmergencyPhrase("🆘","Water rescue needed!"),
            EmergencyPhrase("🚤","Boat engine failure!"),
            EmergencyPhrase("🏄","Surfer in distress!"),
            EmergencyPhrase("🧊","Person trapped in ice!"),
            EmergencyPhrase("🏞️","River flood - stranded on high ground!")
        )),
        PhraseCategory("🧠 Mental Health Crisis", listOf(
            EmergencyPhrase("😰","Mental health crisis - need help!"),
            EmergencyPhrase("💭","Suicidal thoughts - emergency!"),
            EmergencyPhrase("😱","Panic attack - need assistance!"),
            EmergencyPhrase("🆘","Crisis counselor needed!"),
            EmergencyPhrase("📞","Call suicide prevention hotline!"),
            EmergencyPhrase("🤝","I need someone to talk to right now!"),
            EmergencyPhrase("😶","Person is unresponsive / dissociating!"),
            EmergencyPhrase("🏠","Someone needs a welfare check at home!"),
            EmergencyPhrase("💊","Possible overdose emergency!")
        )),
        PhraseCategory("🏭 Workplace Emergency", listOf(
            EmergencyPhrase("⚙️","Workplace accident!"),
            EmergencyPhrase("🏗️","Construction site emergency!"),
            EmergencyPhrase("☣️","Chemical spill - evacuate!"),
            EmergencyPhrase("🔥","Factory fire!"),
            EmergencyPhrase("🦺","Worker trapped - need rescue!"),
            EmergencyPhrase("⚠️","Machinery malfunction!"),
            EmergencyPhrase("💡","Electrical hazard in workplace!"),
            EmergencyPhrase("🏋️","Heavy object fell on worker!"),
            EmergencyPhrase("😷","Toxic fume exposure at work!")
        )),
        PhraseCategory("👩 Women Safety", listOf(
            EmergencyPhrase("😰","I feel unsafe - please help!"),
            EmergencyPhrase("👊","I am being harassed / assaulted!"),
            EmergencyPhrase("🤝","Please stay with me - I'm scared!"),
            EmergencyPhrase("🚪","Someone is trying to break in!"),
            EmergencyPhrase("📱","I need to make an emergency call!"),
            EmergencyPhrase("🆘","Domestic violence emergency!"),
            EmergencyPhrase("🏃","I am being followed - help!"),
            EmergencyPhrase("🚕","Unsafe taxi / ride - need help!")
        )),
        PhraseCategory("✈️ Travel Emergency", listOf(
            EmergencyPhrase("🛂","My passport has been stolen!"),
            EmergencyPhrase("🏛️","I need to contact my embassy!"),
            EmergencyPhrase("📄","I need emergency travel documents!"),
            EmergencyPhrase("💰","I've been robbed - lost all money!"),
            EmergencyPhrase("🏨","I need emergency accommodation!"),
            EmergencyPhrase("✈️","I missed my flight - need help!"),
            EmergencyPhrase("💊","I ran out of essential medication!"),
            EmergencyPhrase("🌍","I don't speak the local language!"),
            EmergencyPhrase("📞","Please connect me to my consulate!")
        )),
        PhraseCategory("💬 Communication", listOf(
            EmergencyPhrase("🗣️","I do not speak this language!"),
            EmergencyPhrase("🇬🇧","Do you speak English?"),
            EmergencyPhrase("🔤","I need a translator!"),
            EmergencyPhrase("✍️","Please write it down for me."),
            EmergencyPhrase("👆","Point to where it hurts."),
            EmergencyPhrase("🤟","I am deaf / hearing impaired."),
            EmergencyPhrase("👁️","I am visually impaired."),
            EmergencyPhrase("📱","Please call this number for me:"),
            EmergencyPhrase("🧠","I have a cognitive disability.")
        )),
        PhraseCategory("🧭 Navigation", listOf(
            EmergencyPhrase("🏥","Where is the nearest hospital?"),
            EmergencyPhrase("💊","Where is the nearest pharmacy?"),
            EmergencyPhrase("🚑","Take me to the emergency room!"),
            EmergencyPhrase("❓","I am lost - please help me!"),
            EmergencyPhrase("📍","This is my current location:"),
            EmergencyPhrase("🗺️","Can you show me on a map?"),
            EmergencyPhrase("🚔","Where is the nearest police station?"),
            EmergencyPhrase("⛽","Where is the nearest petrol station?"),
            EmergencyPhrase("🏦","I need an ATM / bank urgently!")
        )),
        PhraseCategory("🌋 Natural Disaster", listOf(
            EmergencyPhrase("🌍","Earthquake! Drop, cover, hold!"),
            EmergencyPhrase("🌊","Tsunami warning — move to high ground!"),
            EmergencyPhrase("🌪️","Tornado — take shelter immediately!"),
            EmergencyPhrase("🌋","Volcanic eruption — evacuate now!"),
            EmergencyPhrase("🏔️","Landslide / avalanche danger!"),
            EmergencyPhrase("🔥","Wildfire — evacuate the area!"),
            EmergencyPhrase("❄️","Blizzard — seek shelter!"),
            EmergencyPhrase("⚡","Severe storm — stay indoors!"),
            EmergencyPhrase("🌀","Hurricane — board up and shelter!")
        ))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_phrases)

        llPhrases = findViewById(R.id.llPhrases)
        val etSearch = findViewById<EditText>(R.id.etPhraseSearch)

        tts = TextToSpeech(this, this)

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { filterPhrases(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        renderAllCategories(categories)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.ENGLISH
            ttsReady = true
        }
    }

    private fun filterPhrases(q: String) {
        if (q.isBlank()) {
            renderAllCategories(categories)
            return
        }
        val filtered = categories.mapNotNull { cat ->
            val matchedPhrases = cat.phrases.filter {
                it.text.contains(q, true) || it.emoji.contains(q, true) || cat.name.contains(q, true)
            }
            if (matchedPhrases.isNotEmpty()) PhraseCategory(cat.name, matchedPhrases) else null
        }
        renderAllCategories(filtered)
    }

    private fun renderAllCategories(cats: List<PhraseCategory>) {
        llPhrases.removeAllViews()

        if (cats.isEmpty()) {
            val tv = TextView(this).apply {
                text = "No phrases found."
                setPadding(32, 32, 32, 32)
                setTextColor(getColor(R.color.text_secondary))
            }
            llPhrases.addView(tv)
            return
        }

        cats.forEach { cat ->
            // Category header
            val header = TextView(this).apply {
                text = cat.name
                textSize = 15f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(getColor(R.color.accent_blue))
                setPadding(8, 32, 8, 12)
            }
            llPhrases.addView(header)

            // Phrases
            cat.phrases.forEach { phrase ->
                val item = layoutInflater.inflate(R.layout.item_phrase, llPhrases, false)
                item.findViewById<TextView>(R.id.tvPhrase).text = "${phrase.emoji} ${phrase.text}"

                // Tap to copy
                item.setOnClickListener {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("phrase", phrase.text))
                    Toast.makeText(this, "✓ Copied!", Toast.LENGTH_SHORT).show()
                }

                // Long press to speak
                item.setOnLongClickListener {
                    if (ttsReady) {
                        tts?.speak(phrase.text, TextToSpeech.QUEUE_FLUSH, null, null)
                    } else {
                        // Fallback: share
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, phrase.text)
                        }
                        startActivity(Intent.createChooser(intent, "Share Phrase"))
                    }
                    true
                }

                llPhrases.addView(item)
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
