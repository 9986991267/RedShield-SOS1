package com.globalsos.app.ui.donation

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.globalsos.app.R

class DonationActivity : AppCompatActivity() {

    private val paypalUrl = "https://paypal.me/AzhagiriThirupathi"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_donation)

        val cbSafe = findViewById<CheckBox>(R.id.cbDonationSafe)
        val layoutDetails = findViewById<LinearLayout>(R.id.layoutDonationDetails)
        val btnOpen = findViewById<Button>(R.id.btnOpenPaypal)
        val btnCopy = findViewById<Button>(R.id.btnCopyPaypal)
        val tvLink = findViewById<TextView>(R.id.tvPaypalLink)

        tvLink.text = paypalUrl

        cbSafe.setOnCheckedChangeListener { _, checked ->
            layoutDetails.visibility = if (checked) android.view.View.VISIBLE else android.view.View.GONE
        }

        btnOpen.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(paypalUrl)))
        }

        btnCopy.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("PayPal Link", paypalUrl))
            Toast.makeText(this, "✅ Link copied!", Toast.LENGTH_SHORT).show()
        }

        findViewById<ImageButton>(R.id.btnDonateBack).setOnClickListener { finish() }
    }
}
