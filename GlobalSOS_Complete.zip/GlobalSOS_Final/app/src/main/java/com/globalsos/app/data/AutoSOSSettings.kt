package com.globalsos.app.data

import android.content.Context
import android.content.SharedPreferences

data class AutoSOSSettings(
    val batteryEnabled: Boolean = false,
    val batteryThreshold: Int = 15,
    val batteryDelayMins: Int = 5,
    val inactivityEnabled: Boolean = false,
    val inactivityMins: Int = 360,
    val sirenEnabled: Boolean = true,
    val messageType: String = "default", // "default" or "custom"
    val customMessage: String = "",
    val pin: String = "",
    val isMonitorRunning: Boolean = false,
    val monitorStartTime: Long = 0L,
    val sosFired: Boolean = false
)

class AutoSOSSettingsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("auto_sos_settings", Context.MODE_PRIVATE)

    fun save(settings: AutoSOSSettings) {
        prefs.edit().apply {
            putBoolean("bat_enabled", settings.batteryEnabled)
            putInt("bat_threshold", settings.batteryThreshold)
            putInt("bat_delay", settings.batteryDelayMins)
            putBoolean("idle_enabled", settings.inactivityEnabled)
            putInt("idle_mins", settings.inactivityMins)
            putBoolean("siren_enabled", settings.sirenEnabled)
            putString("msg_type", settings.messageType)
            putString("custom_msg", settings.customMessage)
            putString("pin", settings.pin)
            putBoolean("monitor_running", settings.isMonitorRunning)
            putLong("monitor_start", settings.monitorStartTime)
            putBoolean("sos_fired", settings.sosFired)
        }.apply()
    }

    fun load(): AutoSOSSettings = AutoSOSSettings(
        batteryEnabled = prefs.getBoolean("bat_enabled", false),
        batteryThreshold = prefs.getInt("bat_threshold", 15),
        batteryDelayMins = prefs.getInt("bat_delay", 5),
        inactivityEnabled = prefs.getBoolean("idle_enabled", false),
        inactivityMins = prefs.getInt("idle_mins", 360),
        sirenEnabled = prefs.getBoolean("siren_enabled", true),
        messageType = prefs.getString("msg_type", "default") ?: "default",
        customMessage = prefs.getString("custom_msg", "") ?: "",
        pin = prefs.getString("pin", "") ?: "",
        isMonitorRunning = prefs.getBoolean("monitor_running", false),
        monitorStartTime = prefs.getLong("monitor_start", 0L),
        sosFired = prefs.getBoolean("sos_fired", false)
    )

    fun setMonitorRunning(running: Boolean, pin: String = "") {
        val settings = load()
        save(settings.copy(
            isMonitorRunning = running,
            pin = if (pin.isNotEmpty()) pin else settings.pin,
            monitorStartTime = if (running) System.currentTimeMillis() else settings.monitorStartTime,
            sosFired = if (running) false else settings.sosFired
        ))
    }

    fun isMonitorRunning(): Boolean = prefs.getBoolean("monitor_running", false)

    fun markSOSFired() {
        val settings = load()
        save(settings.copy(sosFired = true))
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
