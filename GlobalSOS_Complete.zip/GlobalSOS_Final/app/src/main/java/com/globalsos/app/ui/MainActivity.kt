package com.globalsos.app.ui

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.location.Location
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.SmsManager
import android.text.Editable
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.globalsos.app.R
import com.globalsos.app.data.*
import com.globalsos.app.service.SOSMonitorService
import com.globalsos.app.ui.autoSOS.AutoSOSActivity
import com.globalsos.app.ui.ice.ICECardActivity
import com.globalsos.app.ui.phrases.PhrasesActivity
import com.globalsos.app.ui.shake.ShakeTriggerActivity
import com.globalsos.app.ui.manual.ManualSOSActivity
import com.globalsos.app.ui.readme.ReadMeActivity
import com.globalsos.app.ui.donation.DonationActivity
import com.globalsos.app.ui.reset.ResetActivity
import com.google.android.gms.location.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    // Location
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var currentLat: Double? = null
    private var currentLng: Double? = null
    private var detectedCountryCode: String? = null

    // Torch
    private var torchOn = false
    private var cameraManager: CameraManager? = null
    private var cameraId: String? = null

    // Siren
    private var sirenActive = false
    private var sirenThread: Thread? = null
    private var sirenTrack: AudioTrack? = null

    // Data
    private lateinit var iceManager: ICEProfileManager
    private lateinit var autoSOSManager: AutoSOSSettingsManager

    // Clock
    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClock()
            clockHandler.postDelayed(this, 1000)
        }
    }

    // SOS long press
    private var sosDownTime = 0L
    private val SOS_HOLD_THRESHOLD = 2000L

    // Views
    private lateinit var tvLat: TextView
    private lateinit var tvLng: TextView
    private lateinit var tvAccuracy: TextView
    private lateinit var tvAltitude: TextView
    private lateinit var tvClock: TextView
    private lateinit var tvGpsStatus: TextView
    private lateinit var tvLocation: TextView
    private lateinit var tvBattery: TextView
    private lateinit var sosButton: View
    private lateinit var etSearch: EditText
    private lateinit var llCountries: LinearLayout

    private val locationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { perms ->
            if (perms[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
                startLocationUpdates()
            }
        }

    private val allPermsLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    private val sosFireReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == SOSMonitorService.ACTION_SOS_FIRED) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "🚨 Auto SOS Fired!", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        iceManager = ICEProfileManager(this)
        autoSOSManager = AutoSOSSettingsManager(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        initViews()
        requestPermissions()
        startClockUpdate()
        updateBattery()
        loadCountries("")
        setupSosButton()
        setupSearch()
        setupToolCards()

        try {
            registerReceiver(sosFireReceiver, IntentFilter(SOSMonitorService.ACTION_SOS_FIRED),
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) RECEIVER_NOT_EXPORTED else 0)
        } catch (e: Exception) {}

        detectCountryFromIP()
    }

    private fun initViews() {
        tvLat = findViewById(R.id.tvLat)
        tvLng = findViewById(R.id.tvLng)
        tvAccuracy = findViewById(R.id.tvAccuracy)
        tvAltitude = findViewById(R.id.tvAltitude)
        tvClock = findViewById(R.id.tvClock)
        tvGpsStatus = findViewById(R.id.tvGpsStatus)
        tvLocation = findViewById(R.id.tvLocation)
        tvBattery = findViewById(R.id.tvBattery)
        sosButton = findViewById(R.id.sosButton)
        etSearch = findViewById(R.id.etSearch)
        llCountries = findViewById(R.id.llCountries)
    }

    private fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.SEND_SMS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val notGranted = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (notGranted.isNotEmpty()) {
            allPermsLauncher.launch(notGranted.toTypedArray())
        }
        startLocationUpdates()
    }

    private fun startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            locationPermissionLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
            return
        }

        tvGpsStatus.text = "● GPS Locating..."
        tvGpsStatus.setTextColor(getColor(R.color.accent_orange))

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L)
            .setMinUpdateIntervalMillis(2000L)
            .build()

        fusedLocationClient.requestLocationUpdates(request, object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { updateGPS(it) }
            }
        }, Looper.getMainLooper())
    }

    private fun updateGPS(location: Location) {
        currentLat = location.latitude
        currentLng = location.longitude
        tvLat.text = "%.5f".format(location.latitude)
        tvLng.text = "%.5f".format(location.longitude)
        tvAccuracy.text = "±${location.accuracy.toInt()}m"
        tvAltitude.text = "${location.altitude.toInt()}m"
        tvGpsStatus.text = "● GPS ACTIVE"
        tvGpsStatus.setTextColor(getColor(R.color.accent_green))
    }

    private fun setupSosButton() {
        sosButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    sosDownTime = System.currentTimeMillis()
                    false
                }
                MotionEvent.ACTION_UP -> {
                    val holdDuration = System.currentTimeMillis() - sosDownTime
                    if (holdDuration >= SOS_HOLD_THRESHOLD) {
                        sendSOSSms()
                    } else {
                        dialEmergency()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun dialEmergency() {
        val country = detectCurrentCountry()
        val number = country?.emergency ?: "112"

        AlertDialog.Builder(this)
            .setTitle("📞 Call Emergency")
            .setMessage("Dial $number (${country?.name ?: "International"}) now?")
            .setPositiveButton("CALL $number") { _, _ ->
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number"))
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                    == PackageManager.PERMISSION_GRANTED) {
                    startActivity(intent)
                } else {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun sendSOSSms() {
        val contacts = iceManager.getEmergencyContacts()
        if (contacts.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("No Emergency Contacts")
                .setMessage("Please add emergency contacts in your ICE Card first.")
                .setPositiveButton("Open ICE Card") { _, _ ->
                    startActivity(Intent(this, ICECardActivity::class.java))
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("🚨 Send SOS Alert")
            .setMessage("Send emergency SMS to ${contacts.size} contact(s) with your GPS location?")
            .setPositiveButton("SEND SOS NOW") { _, _ -> doSendSOS() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun buildSOSMessage(reason: String = "Manual SOS"): String {
        val profile = iceManager.load()
        val country = detectCurrentCountry()
        val sb = StringBuilder()

        sb.append("🚨 SOS EMERGENCY ALERT 🚨\n")
        sb.append("Reason: $reason\n\n")
        sb.append("Name: ${profile.fullName.ifBlank { "Unknown" }}\n")
        sb.append("Blood Type: ${profile.bloodType}\n")
        if (country != null) {
            sb.append("Country: ${country.name}\n")
            sb.append("Emergency #: ${country.emergency}\n")
        }
        sb.append("\nI need IMMEDIATE help. Please call emergency services or come to me.\n")

        if (currentLat != null && currentLng != null) {
            sb.append("\n📍 My Location:\nhttps://www.google.com/maps?q=$currentLat,$currentLng\n")
            sb.append("(GPS: $currentLat, $currentLng)\n")
        } else {
            sb.append("\n(GPS Location Unavailable)\n")
        }

        val localE = country?.emergency ?: "112"
        sb.append("\nLocal Emergency: $localE")
        sb.append("\n\nSent via Global SOS")

        return sb.toString()
    }

    private fun doSendSOS() {
        val contacts = iceManager.getEmergencyContacts()
        val msg = buildSOSMessage("Manual SOS")

        contacts.forEach { (_, phone) ->
            try {
                val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    SmsManager.getDefault()
                }
                val parts = smsManager.divideMessage(msg)
                smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
            } catch (e: Exception) {
                val smsIntent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone"))
                smsIntent.putExtra("sms_body", msg)
                startActivity(smsIntent)
            }
        }
        Toast.makeText(this, "✅ SOS Sent to ${contacts.size} contact(s)!", Toast.LENGTH_LONG).show()
    }

    // === WhatsApp Share ===
    fun shareViaWhatsApp() {
        val msg = buildSOSMessage("SOS Alert")
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                setPackage("com.whatsapp")
                putExtra(Intent.EXTRA_TEXT, msg)
            }
            startActivity(intent)
        } catch (e: Exception) {
            // Fallback to regular share
            shareViaSystem()
        }
    }

    // === System Share ===
    fun shareViaSystem() {
        val msg = buildSOSMessage("SOS Alert")
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, msg)
        }
        startActivity(Intent.createChooser(shareIntent, "Share SOS Alert"))
    }

    // === Share Options Dialog ===
    private fun showShareOptions() {
        val contacts = iceManager.getEmergencyContacts()
        val items = mutableListOf<String>()
        items.add("📱 SMS to ICE Contacts" + if (contacts.isNotEmpty()) " (${contacts.size})" else "")
        items.add("💬 WhatsApp")
        items.add("📤 System Share")

        AlertDialog.Builder(this)
            .setTitle("🚨 Share SOS Alert")
            .setItems(items.toTypedArray()) { _, which ->
                when (which) {
                    0 -> if (contacts.isNotEmpty()) doSendSOS() else sendSOSSms()
                    1 -> shareViaWhatsApp()
                    2 -> shareViaSystem()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setupSearch() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                loadCountries(s?.toString() ?: "")
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupToolCards() {
        findViewById<View>(R.id.cardTorch).setOnClickListener { toggleTorch() }
        findViewById<View>(R.id.cardSiren).setOnClickListener { toggleSiren() }
        findViewById<View>(R.id.cardICE).setOnClickListener {
            startActivity(Intent(this, ICECardActivity::class.java))
        }
        findViewById<View>(R.id.cardPhrases).setOnClickListener {
            startActivity(Intent(this, PhrasesActivity::class.java))
        }
        findViewById<View>(R.id.cardAutoSOS).setOnClickListener {
            startActivity(Intent(this, AutoSOSActivity::class.java))
        }
        findViewById<View>(R.id.cardShare).setOnClickListener { showShareOptions() }
        findViewById<View>(R.id.cardMap).setOnClickListener { openMap() }
        findViewById<View>(R.id.cardShake).setOnClickListener {
            startActivity(Intent(this, ShakeTriggerActivity::class.java))
        }
        findViewById<View>(R.id.cardManual).setOnClickListener {
            startActivity(Intent(this, ManualSOSActivity::class.java))
        }
        findViewById<View>(R.id.cardReadMe).setOnClickListener {
            startActivity(Intent(this, ReadMeActivity::class.java))
        }
        findViewById<View>(R.id.cardDonate).setOnClickListener {
            startActivity(Intent(this, DonationActivity::class.java))
        }
        findViewById<View>(R.id.cardReset).setOnClickListener {
            startActivity(Intent(this, ResetActivity::class.java))
        }
        // WhatsApp share card
        try {
            findViewById<View>(R.id.cardWhatsApp)?.setOnClickListener { shareViaWhatsApp() }
        } catch (e: Exception) {}
    }

    private fun toggleTorch() {
        val card = findViewById<View>(R.id.cardTorch)
        val icon = card.findViewById<TextView>(R.id.ivTorchIcon)

        try {
            cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
            if (cameraId == null) {
                cameraId = cameraManager?.cameraIdList?.firstOrNull()
            }
            torchOn = !torchOn
            cameraManager?.setTorchMode(cameraId ?: return, torchOn)
            icon?.text = if (torchOn) "🔆" else "🔦"
            card.alpha = if (torchOn) 1.0f else 0.7f
        } catch (e: Exception) {
            Toast.makeText(this, "Flashlight not available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleSiren() {
        val card = findViewById<View>(R.id.cardSiren)
        val icon = card.findViewById<TextView>(R.id.ivSirenIcon)

        if (sirenActive) {
            sirenActive = false
            sirenThread?.interrupt()
            sirenTrack?.apply { try { stop(); release() } catch (e: Exception) {} }
            sirenTrack = null
            icon?.text = "🔕"
            card.alpha = 0.7f
        } else {
            sirenActive = true
            icon?.text = "🚨"
            card.alpha = 1.0f
            playSiren()
        }
    }

    private fun playSiren() {
        sirenThread = Thread {
            try {
                val sampleRate = 44100
                val bufferSize = AudioTrack.getMinBufferSize(
                    sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                sirenTrack = AudioTrack(
                    AudioManager.STREAM_ALARM,
                    sampleRate, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, bufferSize, AudioTrack.MODE_STREAM
                )
                sirenTrack?.play()

                val buffer = ShortArray(bufferSize)
                var phase = 0.0
                var freq = 450.0
                var goingUp = true

                while (sirenActive && !Thread.currentThread().isInterrupted) {
                    for (i in buffer.indices) {
                        buffer[i] = (Short.MAX_VALUE * Math.sin(phase)).toInt().toShort()
                        phase += 2.0 * Math.PI * freq / sampleRate
                    }
                    sirenTrack?.write(buffer, 0, buffer.size)
                    if (goingUp) { freq += 5.0; if (freq >= 1300) goingUp = false }
                    else { freq -= 5.0; if (freq <= 450) goingUp = true }
                }
            } catch (e: Exception) {}
        }.also { it.start() }
    }

    private fun openMap() {
        if (currentLat != null && currentLng != null) {
            val uri = Uri.parse("geo:$currentLat,$currentLng?q=$currentLat,$currentLng")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        } else {
            Toast.makeText(this, "Waiting for GPS signal...", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadCountries(query: String) {
        llCountries.removeAllViews()
        val results = CountryDatabase.search(query)
        val detected = detectCurrentCountry()

        val sorted = if (detected != null && query.isBlank()) {
            listOf(detected) + results.filter { it.code != detected.code }
        } else results

        // Load ALL countries - no limit
        sorted.forEach { country ->
            val card = layoutInflater.inflate(R.layout.item_country_card, llCountries, false)
            bindCountryCard(card, country, country.code == (detected?.code ?: ""))
            llCountries.addView(card)
        }
    }

    private fun bindCountryCard(view: View, country: CountryEmergency, isDetected: Boolean) {
        view.findViewById<TextView>(R.id.tvCountryFlag).text = country.flag
        view.findViewById<TextView>(R.id.tvCountryName).text = country.name
        if (isDetected) {
            view.setBackgroundResource(R.drawable.bg_country_card_detected)
        }

        val numbers = listOf(
            Triple("🆘 EMERGENCY", country.emergency, R.id.btnEmergency),
            Triple("👮 POLICE", country.police, R.id.btnPolice),
            Triple("🔥 FIRE", country.fire, R.id.btnFire),
            Triple("🚑 MEDICAL", country.medical, R.id.btnMedical),
            Triple("👩 WOMEN", country.women, R.id.btnWomen),
            Triple("🧒 CHILD", country.child, R.id.btnChild),
            Triple("🧠 MENTAL", country.mentalHealth, R.id.btnMental),
            Triple("💻 CYBER", country.cyber, R.id.btnCyber),
            Triple("👴 SENIOR", country.senior, R.id.btnSenior),
            Triple("✈️ TOURIST", country.tourist, R.id.btnTourist),
            Triple("☠️ POISON", country.poison, R.id.btnPoison),
            Triple("🌪️ DISASTER", country.disaster, R.id.btnDisaster),
            Triple("🐾 ANIMAL", country.animal, R.id.btnAnimal)
        )

        numbers.forEach { (label, number, viewId) ->
            view.findViewById<TextView>(viewId)?.apply {
                text = "$label\n$number"
                if (number.isBlank()) {
                    alpha = 0.3f
                    isClickable = false
                } else {
                    alpha = 1f
                    setOnClickListener {
                        val clean = number.replace(Regex("[^0-9+*#]"), "")
                        if (clean.isNotBlank()) {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$clean"))
                            startActivity(intent)
                        }
                    }
                }
            }
        }
    }

    fun detectCurrentCountry(): CountryEmergency? {
        // Try detected CC first
        detectedCountryCode?.let { code ->
            CountryDatabase.getByCode(code)?.let { return it }
        }
        // Timezone fallback
        val tz = TimeZone.getDefault().id
        val code = when {
            tz.contains("India") || tz.contains("Calcutta") || tz.contains("Kolkata") -> "IN"
            tz.contains("London") -> "GB"
            tz.contains("New_York") || tz.contains("Chicago") || tz.contains("Los_Angeles") || tz.contains("Denver") -> "US"
            tz.contains("Sydney") || tz.contains("Melbourne") -> "AU"
            tz.contains("Tokyo") -> "JP"
            tz.contains("Shanghai") || tz.contains("Beijing") -> "CN"
            tz.contains("Dubai") -> "AE"
            tz.contains("Paris") -> "FR"
            tz.contains("Berlin") -> "DE"
            tz.contains("Toronto") || tz.contains("Vancouver") -> "CA"
            tz.contains("Singapore") -> "SG"
            tz.contains("Seoul") -> "KR"
            tz.contains("Sao_Paulo") -> "BR"
            tz.contains("Moscow") -> "RU"
            tz.contains("Istanbul") -> "TR"
            tz.contains("Bangkok") -> "TH"
            tz.contains("Jakarta") -> "ID"
            tz.contains("Manila") -> "PH"
            tz.contains("Kuala_Lumpur") -> "MY"
            tz.contains("Riyadh") -> "SA"
            tz.contains("Cairo") -> "EG"
            tz.contains("Nairobi") -> "KE"
            tz.contains("Lagos") -> "NG"
            tz.contains("Johannesburg") -> "ZA"
            tz.contains("Mexico") -> "MX"
            tz.contains("Buenos_Aires") -> "AR"
            tz.contains("Lima") -> "PE"
            tz.contains("Bogota") -> "CO"
            tz.contains("Santiago") -> "CL"
            tz.contains("Auckland") || tz.contains("Wellington") -> "NZ"
            tz.contains("Dhaka") -> "BD"
            tz.contains("Karachi") || tz.contains("Islamabad") -> "PK"
            tz.contains("Colombo") -> "LK"
            tz.contains("Kathmandu") -> "NP"
            else -> null
        }
        return code?.let { CountryDatabase.getByCode(it) }
    }

    private fun detectCountryFromIP() {
        Thread {
            try {
                val url = java.net.URL("https://ipapi.co/json/")
                val conn = url.openConnection()
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                val json = conn.getInputStream().bufferedReader().readText()
                val codeMatch = Regex("\"country_code\":\"([A-Z]{2})\"").find(json)
                val nameMatch = Regex("\"country_name\":\"([^\"]+)\"").find(json)
                val code = codeMatch?.groupValues?.get(1) ?: return@Thread
                val name = nameMatch?.groupValues?.get(1) ?: code
                detectedCountryCode = code
                runOnUiThread {
                    tvLocation.text = name
                    loadCountries(etSearch.text?.toString() ?: "")
                }
            } catch (e: Exception) {
                // Silent fail - timezone fallback is used
            }
        }.start()
    }

    private fun startClockUpdate() {
        clockHandler.post(clockRunnable)
    }

    private fun updateClock() {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        tvClock.text = sdf.format(Date())
    }

    private fun updateBattery() {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (level != -1 && scale != -1) {
            val pct = (level * 100 / scale)
            tvBattery.text = "$pct%"
            if (pct < 20) tvBattery.setTextColor(getColor(R.color.accent_red))
        }
    }

    override fun onResume() {
        super.onResume()
        updateBattery()
    }

    override fun onDestroy() {
        super.onDestroy()
        clockHandler.removeCallbacks(clockRunnable)
        if (sirenActive) {
            sirenActive = false
            sirenThread?.interrupt()
            sirenTrack?.apply { try { stop(); release() } catch (e: Exception) {} }
        }
        try { unregisterReceiver(sosFireReceiver) } catch (e: Exception) {}
    }
}
