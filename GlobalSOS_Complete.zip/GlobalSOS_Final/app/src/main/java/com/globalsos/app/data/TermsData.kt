package com.globalsos.app.data

import android.content.Context
import android.content.SharedPreferences

class TermsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("terms_prefs", Context.MODE_PRIVATE)

    fun hasAccepted(): Boolean = prefs.getBoolean("terms_accepted", false)

    fun setAccepted(accepted: Boolean) {
        prefs.edit().putBoolean("terms_accepted", accepted).apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }

    companion object {
        val TERMS_ITEMS = listOf(
            "Emergency numbers are for reference only and may be outdated or incorrect.",
            "You are solely responsible for verifying emergency numbers locally.",
            "This app does NOT replace official emergency or medical services.",
            "No personal data is collected, stored, or transmitted to any server.",
            "Location, SOS, flashlight, and calling activate only when you trigger them.",
            "Donations are optional, voluntary, and non-refundable.",
            "The app is provided \"AS IS\" and \"AS AVAILABLE\" with absolutely no guarantees.",
            "Developer and owner are NOT liable for injury, loss, damage, delay, or death.",
            "SMS/call charges depend on your carrier and country. Developer is NOT responsible.",
            "Background services require device permissions configured by the user.",
            "SMS delivery, call connectivity, and GPS accuracy depend entirely on your device, network, and carrier.",
            "The developer makes NO guarantee that SOS alerts, SMS, or calls will be delivered or received.",
            "You acknowledge that mobile networks, GPS, and internet may fail at any time without warning.",
            "This app shall NOT be your sole means of emergency communication. Always have backup plans.",
            "The developer is not responsible for misuse, false alarms, or unintended SOS triggers by the user.",
            "You agree to use this app lawfully and take full responsibility for all actions performed through it.",
            "No warranty — express, implied, or statutory — is provided, including fitness for any particular purpose.",
            "You waive all claims, demands, and causes of action against the developer, owner, and contributors.",
            "Under no circumstances shall the total liability of the developer exceed the amount paid by you (zero).",
            "The developer reserves the right to modify, suspend, or discontinue the app at any time without notice."
        )

        const val CRITICAL_WARNING =
            "⚠️ CRITICAL: This app is a supplementary safety tool ONLY. It does NOT guarantee emergency response. " +
            "If you do NOT agree to ALL terms above, press Decline and stop using this application immediately."

        const val FULL_TERMS = """
THIS APPLICATION IS NOT AN EMERGENCY SERVICE. Emergency numbers provided within this app are for general reference only and may be incorrect, outdated, incomplete, or unavailable in your location or region. The developer does not guarantee the accuracy, completeness, or availability of any emergency number listed.

You are solely and entirely responsible for knowing and verifying the correct emergency numbers for your location. This app must NOT be relied upon as your primary or sole means of contacting emergency services.

LIMITATION OF LIABILITY: Under NO circumstances shall the developer, owner, contributors, affiliates, or any associated parties be liable for ANY form of damages whatsoever, including but not limited to: direct, indirect, incidental, special, consequential, or punitive damages, loss of life, personal injury, property damage, loss of data, loss of profits, or any other losses.

By using this application, you expressly agree:
• You will verify all emergency numbers independently before relying on them
• You understand this app may contain errors, bugs, or inaccuracies
• You accept ALL risks associated with using this application
• You release the developer from ALL liability whatsoever
• You will maintain alternative means of contacting emergency services

SMS & COMMUNICATION CHARGES: This application may send SMS messages and initiate phone calls on your behalf when you trigger SOS features. Standard messaging and calling rates from your mobile carrier apply. The developer has no control over and accepts no responsibility for any charges, fees, or costs imposed by your telecommunications provider.

THIRD-PARTY SERVICES: This app may interact with third-party services (Google Maps for location links, device SMS service, phone dialer, WhatsApp for sharing). The developer is not responsible for the availability, accuracy, or functionality of any third-party service.

MAXIMUM AGGREGATE LIABILITY: The total aggregate liability of the developer arising from or related to your use of this application shall not exceed ZERO (the amount you paid for the app).

This disclaimer constitutes the entire agreement between you and the developer regarding the use of this application.
"""

        const val FULL_PRIVACY = """
PRIVACY POLICY — Global SOS / RedShield SOS

1. DATA COLLECTION: This application does NOT collect, store, transmit, or share any personal data to external servers. All data (ICE profiles, emergency contacts, settings) is stored locally on your device only.

2. LOCATION DATA: GPS coordinates are accessed only when you explicitly trigger location-dependent features (SOS sharing, GPS display). Location data is NOT transmitted to any server and is used only for creating map links in emergency messages.

3. SMS & CALLS: When you trigger SOS features, the app uses your device's native SMS and calling capabilities. Message content and call logs are handled by your device's operating system and carrier, not by this app.

4. CONTACTS: Emergency contact information you enter is stored locally on your device in SharedPreferences. This data is never uploaded or shared with any third party.

5. CAMERA/FLASHLIGHT: Camera access is used solely for the flashlight/torch feature. No photos or videos are captured or stored.

6. SENSORS: Accelerometer data is used only for shake detection (Shake SOS feature) and is processed locally in real-time. No sensor data is stored or transmitted.

7. INTERNET ACCESS: Internet is used only for: (a) IP-based country detection on first launch, (b) opening map links. No personal data is transmitted.

8. THIRD-PARTY SERVICES: The app may interact with Google Maps (for location links), WhatsApp (for sharing), and your device's native dialer and SMS apps. These services have their own privacy policies.

9. CHILDREN'S PRIVACY: This app does not knowingly collect information from children under 13.

10. CHANGES: This privacy policy may be updated. Continued use of the app constitutes acceptance of any changes.

Contact: redshieldsos@gmail.com
"""
    }
}
