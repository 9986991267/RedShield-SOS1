package com.globalsos.app.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson

data class ICEProfile(
    val fullName: String = "",
    val bloodType: String = "Unknown",
    val dateOfBirth: String = "",
    val medicalNotes: String = "",
    val insuranceProvider: String = "",
    val policyNumber: String = "",
    val contact1Name: String = "",
    val contact1Phone: String = "",
    val contact2Name: String = "",
    val contact2Phone: String = ""
)

class ICEProfileManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ice_profile", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun save(profile: ICEProfile) {
        prefs.edit().putString("profile", gson.toJson(profile)).apply()
    }

    fun load(): ICEProfile {
        val json = prefs.getString("profile", null) ?: return ICEProfile()
        return try {
            gson.fromJson(json, ICEProfile::class.java)
        } catch (e: Exception) {
            ICEProfile()
        }
    }

    fun isLocked(): Boolean = prefs.getBoolean("locked", false)

    fun setLocked(locked: Boolean) {
        prefs.edit().putBoolean("locked", locked).apply()
    }

    fun hasContacts(): Boolean {
        val profile = load()
        return profile.contact1Phone.isNotBlank() || profile.contact2Phone.isNotBlank()
    }

    fun getEmergencyContacts(): List<Pair<String, String>> {
        val profile = load()
        val contacts = mutableListOf<Pair<String, String>>()
        if (profile.contact1Phone.isNotBlank()) {
            contacts.add(Pair(profile.contact1Name.ifBlank { "Contact 1" }, profile.contact1Phone))
        }
        if (profile.contact2Phone.isNotBlank()) {
            contacts.add(Pair(profile.contact2Name.ifBlank { "Contact 2" }, profile.contact2Phone))
        }
        return contacts
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
