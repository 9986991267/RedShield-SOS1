package com.globalsos.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.*
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import com.globalsos.app.GlobalSOSApp
import com.globalsos.app.R
import com.globalsos.app.data.AutoSOSSettingsManager
import com.globalsos.app.data.ICEProfileManager
import com.globalsos.app.ui.MainActivity
import com.google.android.gms.location.*
import kotlin.math.sqrt

class SOSMonitorService : Service(), SensorEventListener {

    companion object {
        const val ACTION_START = "com.globalsos.service.START"
        const val ACTION_STOP = "com.globalsos.service.STOP"
        const val ACTION_SOS_FIRED = "com.globalsos.service.SOS_FIRED"
        const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            val intent = Intent(context, SOSMonitorService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, SOSMonitorService::class.java).apply {
                action = ACTION_STOP
            }
            context.stopService(intent)
        }
    }

    private lateinit var settingsManager: AutoSOSSettingsManager
    private lateinit var iceManager: ICEProfileManager
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var sensorManager: SensorManager

    private var handler: Handler? = null
    private var checkRunnable: Runnable? = null
    private var lastActivity = System.currentTimeMillis()
    private var batteryLevel = 100
    private var isCharging = false
    private var currentLat: Double? = null
    private var currentLng: Double? = null
    private var sosAlreadyFired = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: return
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            batteryLevel = if (scale > 0) (level * 100 / scale) else level
            isCharging = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ==
                    BatteryManager.BATTERY_STATUS_CHARGING
        }
    }

    override fun onCreate() {
        super.onCreate()
        settingsManager = AutoSOSSettingsManager(this)
        iceManager = ICEProfileManager(this)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        handler = Handler(Looper.getMainLooper())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        val accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (accel != null) {
            sensorManager.registerListener(this, accel, SensorManager.SENSOR_DELAY_NORMAL)
        }

        startLocationUpdates()
        scheduleChecks()

        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, GlobalSOSApp.CHANNEL_SOS_MONITOR)
            .setContentTitle("🛡️ SOS Monitor Active")
            .setContentText("Watching for battery & inactivity triggers")
            .setSmallIcon(R.drawable.ic_sos_notification)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun startLocationUpdates() {
        try {
            val request = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, 60_000L).build()
            fusedLocationClient.requestLocationUpdates(request, object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    result.lastLocation?.let {
                        currentLat = it.latitude
                        currentLng = it.longitude
                    }
                }
            }, Looper.getMainLooper())
        } catch (e: SecurityException) {
            // Permission not granted
        }
    }

    private fun scheduleChecks() {
        val settings = settingsManager.load()
        checkRunnable = Runnable {
            runChecks()
            handler?.postDelayed(checkRunnable!!, 60_000L)
        }
        handler?.postDelayed(checkRunnable!!, 60_000L)
    }

    private fun runChecks() {
        if (sosAlreadyFired) return
        val settings = settingsManager.load()

        // Battery check
        if (settings.batteryEnabled) {
            val idleMins = (System.currentTimeMillis() - lastActivity) / 60_000
            val meetsDelay = idleMins >= settings.batteryDelayMins
            if (batteryLevel <= settings.batteryThreshold && !isCharging && meetsDelay) {
                fireSOS("Battery Critical (${batteryLevel}%)")
                return
            }
        }

        // Inactivity check
        if (settings.inactivityEnabled) {
            val idleMins = (System.currentTimeMillis() - lastActivity) / 60_000
            if (idleMins >= settings.inactivityMins) {
                fireSOS("Inactivity (${idleMins}m)")
            }
        }
    }

    private fun fireSOS(reason: String) {
        sosAlreadyFired = true
        settingsManager.markSOSFired()

        val contacts = iceManager.getEmergencyContacts()
        val msg = buildSosMessage(reason)

        // Send SMS to all contacts
        contacts.forEach { (name, phone) ->
            try {
                val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    SmsManager.getDefault()
                }
                val parts = smsManager.divideMessage(msg)
                smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // Broadcast that SOS was fired
        sendBroadcast(Intent(ACTION_SOS_FIRED))
    }

    private fun buildSosMessage(reason: String): String {
        val settings = settingsManager.load()
        val profile = iceManager.load()

        var msg = if (settings.messageType == "custom" && settings.customMessage.isNotBlank()) {
            settings.customMessage
        } else {
            "🚨 SOS EMERGENCY ALERT 🚨\n" +
            "Name: ${profile.fullName.ifBlank { "Unknown" }}\n" +
            "Blood Type: ${profile.bloodType}\n" +
            "Trigger: $reason\n" +
            "Please respond or call emergency services immediately."
        }

        if (currentLat != null && currentLng != null) {
            msg += "\n\n📍 GPS Location:\nhttps://www.google.com/maps?q=$currentLat,$currentLng"
        } else {
            msg += "\n\n(GPS Location Unavailable)"
        }

        return msg
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_ACCELEROMETER) {
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]
            val magnitude = sqrt((x * x + y * y + z * z).toDouble())
            // Any significant movement resets activity timer
            if (magnitude > 1.5) {
                lastActivity = System.currentTimeMillis()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDestroy() {
        super.onDestroy()
        handler?.removeCallbacksAndMessages(null)
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) {}
        sensorManager.unregisterListener(this)
        settingsManager.setMonitorRunning(false)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
