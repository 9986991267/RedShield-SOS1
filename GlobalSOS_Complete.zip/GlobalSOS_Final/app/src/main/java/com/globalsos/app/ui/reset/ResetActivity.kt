package com.globalsos.app.ui.reset

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.globalsos.app.R
import com.globalsos.app.data.AutoSOSSettingsManager
import com.globalsos.app.data.ICEProfileManager
import kotlin.random.Random

class ResetActivity : AppCompatActivity() {

    private lateinit var iceManager: ICEProfileManager
    private lateinit var autoSOSManager: AutoSOSSettingsManager

    private lateinit var cbResetPhrases: CheckBox
    private lateinit var cbResetICE: CheckBox
    private lateinit var cbResetSettings: CheckBox
    private lateinit var tvPuzzle: TextView
    private lateinit var etPuzzleAnswer: EditText
    private lateinit var btnReset: Button

    private var puzzleAnswer = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset)

        iceManager = ICEProfileManager(this)
        autoSOSManager = AutoSOSSettingsManager(this)

        initViews()
        generatePuzzle()

        findViewById<ImageButton>(R.id.btnResetBack).setOnClickListener { finish() }
    }

    private fun initViews() {
        cbResetPhrases = findViewById(R.id.cbResetPhrases)
        cbResetICE = findViewById(R.id.cbResetICE)
        cbResetSettings = findViewById(R.id.cbResetSettings)
        tvPuzzle = findViewById(R.id.tvResetPuzzle)
        etPuzzleAnswer = findViewById(R.id.etResetAnswer)
        btnReset = findViewById(R.id.btnExecuteReset)

        btnReset.setOnClickListener { attemptReset() }
    }

    private fun generatePuzzle() {
        val a = Random.nextInt(10, 99)
        val b = Random.nextInt(10, 99)
        val operator = if (Random.nextBoolean()) "+" else "×"
        puzzleAnswer = if (operator == "+") a + b else a * b
        tvPuzzle.text = "🔐 Security Check: What is $a $operator $b?"
    }

    private fun attemptReset() {
        // Validate something is selected
        if (!cbResetPhrases.isChecked && !cbResetICE.isChecked && !cbResetSettings.isChecked) {
            Toast.makeText(this, "⚠️ Please select at least one item to reset", Toast.LENGTH_SHORT).show()
            return
        }

        // Validate puzzle
        val answer = etPuzzleAnswer.text.toString().trim().toIntOrNull()
        if (answer != puzzleAnswer) {
            Toast.makeText(this, "❌ Wrong answer! Please try again.", Toast.LENGTH_SHORT).show()
            etPuzzleAnswer.text.clear()
            generatePuzzle()
            return
        }

        // Confirm dialog
        val items = mutableListOf<String>()
        if (cbResetPhrases.isChecked) items.add("• Emergency Phrases")
        if (cbResetICE.isChecked) items.add("• ICE Card Data")
        if (cbResetSettings.isChecked) items.add("• App Settings")

        AlertDialog.Builder(this)
            .setTitle("⚠️ Confirm Reset")
            .setMessage("This will permanently delete:\n\n${items.joinToString("\n")}\n\nThis cannot be undone!")
            .setPositiveButton("RESET NOW") { _, _ ->
                executeReset()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun executeReset() {
        var resetCount = 0

        if (cbResetPhrases.isChecked) {
            // Clear phrases from SharedPreferences
            val prefs = getSharedPreferences("phrases", MODE_PRIVATE)
            prefs.edit().clear().apply()
            resetCount++
        }

        if (cbResetICE.isChecked) {
            iceManager.clear()
            resetCount++
        }

        if (cbResetSettings.isChecked) {
            autoSOSManager.clearAll()
            // Also clear shake settings
            getSharedPreferences("shake_settings", MODE_PRIVATE).edit().clear().apply()
            resetCount++
        }

        // Reset puzzle and checkboxes
        cbResetPhrases.isChecked = false
        cbResetICE.isChecked = false
        cbResetSettings.isChecked = false
        etPuzzleAnswer.text.clear()
        generatePuzzle()

        Toast.makeText(this, "✅ Reset complete! $resetCount item(s) cleared.", Toast.LENGTH_LONG).show()
    }
}
