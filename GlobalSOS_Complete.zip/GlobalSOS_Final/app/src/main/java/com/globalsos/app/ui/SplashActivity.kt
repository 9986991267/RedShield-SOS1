package com.globalsos.app.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.globalsos.app.R
import com.globalsos.app.data.TermsManager

class SplashActivity : AppCompatActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var termsManager: TermsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        termsManager = TermsManager(this)

        setContentView(R.layout.activity_splash)

        if (termsManager.hasAccepted()) {
            handler.postDelayed({
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }, 2000)
        } else {
            handler.postDelayed({
                val termsLayout = findViewById<LinearLayout>(R.id.termsContainer)
                val splashContent = findViewById<View>(R.id.splashContent)
                splashContent?.visibility = View.GONE
                termsLayout?.visibility = View.VISIBLE

                findViewById<Button>(R.id.btnAgree)?.setOnClickListener {
                    termsManager.setAccepted(true)
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
                findViewById<Button>(R.id.btnDecline)?.setOnClickListener {
                    showDenialScreen()
                }
            }, 1500)
        }
    }

    private fun showDenialScreen() {
        findViewById<View>(R.id.termsContainer)?.visibility = View.GONE
        findViewById<View>(R.id.denialContainer)?.visibility = View.VISIBLE
    }
}
