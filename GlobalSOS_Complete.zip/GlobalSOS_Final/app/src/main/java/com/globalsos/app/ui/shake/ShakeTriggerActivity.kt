package com.globalsos.app.ui.shake

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.globalsos.app.R
import com.globalsos.app.data.ShakeSettings
import com.globalsos.app.data.ShakeSettingsManager
import com.globalsos.app.service.ShakeDetectorService

class ShakeTriggerActivity : AppCompatActivity() {

    private lateinit var shakeManager: ShakeSettingsManager

    // UI
    private lateinit var tvStatus: TextView
    private lateinit var swEnable: Switch
    private lateinit var spShakesNeeded: Spinner
    private lateinit var spWindow: Spinner
    private lateinit var spMaxAlerts: Spinner
    private lateinit var spSensitivity: Spinner
    private lateinit var spCooldown: Spinner
    private lateinit var rgMsgType: RadioGroup
    private lateinit var rbDefault: RadioButton
    private lateinit var rbCustom: RadioButton
    private lateinit var rbBoth: RadioButton
    private lateinit var etCustomMsg: EditText
    private lateinit var swSiren: Switch
    private lateinit var swReoccur: Switch
    private lateinit var layoutReoccur: LinearLayout
    private lateinit var spReoccurCount: Spinner
    private lateinit var spReoccurGap: Spinner
    private lateinit var tvAlertCount: TextView

    private val shakeReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action == ShakeDetectorService.ACTION_SHAKE_FIRED) {
                runOnUiThread { updateAlertCountDisplay() }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shake_trigger)
        shakeManager = ShakeSettingsManager(this)
        initViews()
        loadSettings()
        registerReceiver(shakeReceiver, IntentFilter(ShakeDetectorService.ACTION_SHAKE_FIRED))
    }

    private fun initViews() {
        tvStatus = findViewById(R.id.tvShakeStatus)
        swEnable = findViewById(R.id.swShakeEnable)
        spShakesNeeded = findViewById(R.id.spShakesNeeded)
        spWindow = findViewById(R.id.spShakeWindow)
        spMaxAlerts = findViewById(R.id.spShakeMaxAlerts)
        spSensitivity = findViewById(R.id.spShakeSensitivity)
        spCooldown = findViewById(R.id.spShakeCooldown)
        rgMsgType = findViewById(R.id.rgShakeMsgType)
        rbDefault = findViewById(R.id.rbShakeDefault)
        rbCustom = findViewById(R.id.rbShakeCustom)
        rbBoth = findViewById(R.id.rbShakeBoth)
        etCustomMsg = findViewById(R.id.etShakeCustomMsg)
        swSiren = findViewById(R.id.swShakeSiren)
        swReoccur = findViewById(R.id.swShakeReoccur)
        layoutReoccur = findViewById(R.id.layoutShakeReoccur)
        spReoccurCount = findViewById(R.id.spShakeReoccurCount)
        spReoccurGap = findViewById(R.id.spShakeReoccurGap)
        tvAlertCount = findViewById(R.id.tvShakeAlertCount)

        // Spinners
        spShakesNeeded.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("2 shakes", "3 shakes", "4 shakes", "5 shakes", "7 shakes"))
        spWindow.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("1 second", "1.5 seconds", "2 seconds", "3 seconds", "5 seconds"))
        spMaxAlerts.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("1 alert", "2 alerts", "3 alerts", "5 alerts", "10 alerts"))
        spSensitivity.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Low (gentle)", "Medium (normal)", "High (vigorous)", "Very Low"))
        spCooldown.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("5 seconds", "10 seconds", "30 seconds", "1 minute"))
        spReoccurCount.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("2 times", "3 times", "5 times", "10 times", "Unlimited"))
        spReoccurGap.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("30 seconds", "1 minute", "2 minutes", "5 minutes", "10 minutes"))

        // Enable toggle
        swEnable.setOnCheckedChangeListener { _, checked ->
            saveAndApply()
            updateStatusUI(checked)
        }

        // Custom message visibility
        rgMsgType.setOnCheckedChangeListener { _, id ->
            etCustomMsg.visibility = if (id == R.id.rbShakeCustom || id == R.id.rbShakeBoth)
                android.view.View.VISIBLE else android.view.View.GONE
        }

        // Re-occur toggle
        swReoccur.setOnCheckedChangeListener { _, checked ->
            layoutReoccur.visibility = if (checked) android.view.View.VISIBLE else android.view.View.GONE
        }

        // Back button
        findViewById<ImageButton>(R.id.btnShakeBack).setOnClickListener {
            saveAndApply()
            finish()
        }
    }

    private fun loadSettings() {
        val s = shakeManager.load()

        swEnable.isChecked = s.enabled
        updateStatusUI(s.enabled)

        // Map values to spinner positions
        spShakesNeeded.setSelection(when(s.shakesNeeded) { 2->0; 3->1; 4->2; 5->3; else->4 })
        spWindow.setSelection(when(s.detectionWindowMs) { 1000L->0; 1500L->1; 2000L->2; 3000L->3; else->4 })
        spMaxAlerts.setSelection(when(s.maxAlerts) { 1->0; 2->1; 3->2; 5->3; else->4 })
        spSensitivity.setSelection(when(s.sensitivity) { 20->0; 15->1; 10->2; 25->3; else->1 })
        spCooldown.setSelection(when(s.cooldownSecs) { 5->0; 10->1; 30->2; 60->3; else->1 })
        when(s.messageType) {
            "custom" -> rbCustom.isChecked = true
            "both" -> rbBoth.isChecked = true
            else -> rbDefault.isChecked = true
        }
        etCustomMsg.setText(s.customMessage)
        etCustomMsg.visibility = if (s.messageType != "default") android.view.View.VISIBLE else android.view.View.GONE
        swSiren.isChecked = s.sirenEnabled
        swReoccur.isChecked = s.reoccurEnabled
        layoutReoccur.visibility = if (s.reoccurEnabled) android.view.View.VISIBLE else android.view.View.GONE
        spReoccurCount.setSelection(when(s.reoccurMaxCount) { 2->0; 3->1; 5->2; 10->3; 0->4; else->1 })
        spReoccurGap.setSelection(when(s.reoccurGapSecs) { 30L->0; 60L->1; 120L->2; 300L->3; else->4 })
    }

    private fun buildSettings(): ShakeSettings {
        val shakesNeeded = when(spShakesNeeded.selectedItemPosition) { 0->2; 1->3; 2->4; 3->5; else->7 }
        val windowMs = when(spWindow.selectedItemPosition) { 0->1000L; 1->1500L; 2->2000L; 3->3000L; else->5000L }
        val maxAlerts = when(spMaxAlerts.selectedItemPosition) { 0->1; 1->2; 2->3; 3->5; else->10 }
        val sensitivity = when(spSensitivity.selectedItemPosition) { 0->20; 1->15; 2->10; 3->25; else->15 }
        val cooldown = when(spCooldown.selectedItemPosition) { 0->5; 1->10; 2->30; else->60 }
        val msgType = when(rgMsgType.checkedRadioButtonId) { R.id.rbShakeCustom->"custom"; R.id.rbShakeBoth->"both"; else->"default" }
        val reoccurCount = when(spReoccurCount.selectedItemPosition) { 0->2; 1->3; 2->5; 3->10; else->0 }
        val reoccurGap = when(spReoccurGap.selectedItemPosition) { 0->30L; 1->60L; 2->120L; 3->300L; else->600L }

        return ShakeSettings(
            enabled = swEnable.isChecked,
            shakesNeeded = shakesNeeded,
            detectionWindowMs = windowMs,
            maxAlerts = maxAlerts,
            sensitivity = sensitivity,
            cooldownSecs = cooldown,
            messageType = msgType,
            customMessage = etCustomMsg.text.toString(),
            sirenEnabled = swSiren.isChecked,
            reoccurEnabled = swReoccur.isChecked,
            reoccurMaxCount = reoccurCount,
            reoccurGapSecs = reoccurGap
        )
    }

    private fun saveAndApply() {
        val s = buildSettings()
        shakeManager.save(s)
        if (s.enabled) {
            ShakeDetectorService.start(this)
        } else {
            ShakeDetectorService.stop(this)
        }
    }

    private fun updateStatusUI(enabled: Boolean) {
        if (enabled) {
            tvStatus.text = "✅ SHAKE SOS IS ON"
            tvStatus.setBackgroundResource(R.drawable.bg_shake_status_on)
            tvStatus.setTextColor(getColor(android.R.color.holo_green_light))
        } else {
            tvStatus.text = "❌ SHAKE SOS IS OFF"
            tvStatus.setBackgroundResource(R.drawable.bg_shake_status_off)
            tvStatus.setTextColor(getColor(android.R.color.holo_red_light))
        }
    }

    private fun updateAlertCountDisplay() {
        // Could track locally, show toast
        Toast.makeText(this, "🚨 Shake SOS Fired!", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(shakeReceiver) } catch (e: Exception) {}
    }
}
