package com.globalsos.app.ui.readme

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.globalsos.app.R
import com.globalsos.app.data.TermsManager

class ReadMeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_readme)
        
        findViewById<ImageButton>(R.id.btnReadMeBack).setOnClickListener { finish() }
        
        // Set Terms content
        findViewById<TextView>(R.id.tvTermsContent)?.text = TermsManager.FULL_TERMS.trim()
        
        // Set Privacy content
        findViewById<TextView>(R.id.tvPrivacyContent)?.text = TermsManager.FULL_PRIVACY.trim()
        
        // Toggle Terms section
        findViewById<View>(R.id.btnToggleTerms)?.setOnClickListener {
            val content = findViewById<TextView>(R.id.tvTermsContent)
            content?.visibility = if (content?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        
        // Toggle Privacy section
        findViewById<View>(R.id.btnTogglePrivacy)?.setOnClickListener {
            val content = findViewById<TextView>(R.id.tvPrivacyContent)
            content?.visibility = if (content?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        
        // Contact developer
        findViewById<View>(R.id.btnContactDev)?.setOnClickListener {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:redshieldsos@gmail.com")
                putExtra(Intent.EXTRA_SUBJECT, "Global SOS - Feedback")
            }
            try { startActivity(intent) } catch (e: Exception) {
                Toast.makeText(this, "No email app found", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
