package com.globalsos.app.ui.manual

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.media.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.telephony.SmsManager
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.globalsos.app.R
import com.globalsos.app.data.ICEProfileManager
import com.google.android.gms.location.*
import java.text.SimpleDateFormat
import java.util.*

class ManualSOSActivity : AppCompatActivity() {

    private lateinit var iceManager: ICEProfileManager
    private lateinit var fusedLocation: FusedLocationProviderClient

    private var currentLat: Double? = null
    private var currentLng: Double? = null
    private var sirenActive = false
    private var sirenThread: Thread? = null
    private var sirenTrack: AudioTrack? = null

    private lateinit var cbDefaultMsg: CheckBox
    private lateinit var cbCustomMsg: CheckBox
    private lateinit var etCustomMsg: EditText
    private lateinit var swSiren: Switch
    private lateinit var tvGpsStatus: TextView
    private lateinit var tvMsgPreview: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manual_sos)
        iceManager = ICEProfileManager(this)
        fusedLocation = LocationServices.getFusedLocationProviderClient(this)

        initViews()
        startLocationUpdates()
        updatePreview()

        findViewById<ImageButton>(R.id.btnManualBack).setOnClickListener { finish() }
    }

    private fun initViews() {
        cbDefaultMsg = findViewById(R.id.cbManualDefault)
        cbCustomMsg = findViewById(R.id.cbManualCustom)
        etCustomMsg = findViewById(R.id.etManualCustom)
        swSiren = findViewById(R.id.swManualSiren)
        tvGpsStatus = findViewById(R.id.tvManualGpsStatus)
        tvMsgPreview = findViewById(R.id.tvManualPreview)

        cbDefaultMsg.setOnCheckedChangeListener { _, _ -> updatePreview() }
        cbCustomMsg.setOnCheckedChangeListener { _, checked ->
            etCustomMsg.visibility = if (checked) android.view.View.VISIBLE else android.view.View.GONE
            updatePreview()
        }
        etCustomMsg.setOnFocusChangeListener { _, _ -> updatePreview() }

        // Action buttons
        findViewById<Button>(R.id.btnManualSystem).setOnClickListener { doSystemShare() }
        findViewById<Button>(R.id.btnManualWhatsApp).setOnClickListener { doWhatsAppShare() }
        findViewById<Button>(R.id.btnManualSms).setOnClickListener { doSmsShare() }
        findViewById<Button>(R.id.btnManualCall).setOnClickListener { doEmergencyCall() }
        findViewById<Button>(R.id.btnManualSiren).setOnClickListener { toggleSiren() }
    }

    private fun startLocationUpdates() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            tvGpsStatus.text = "📍 GPS: Permission required"
            return
        }
        tvGpsStatus.text = "📡 GPS: Locating..."
        val req = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 3000L).build()
        fusedLocation.requestLocationUpdates(req, object : LocationCallback() {
            override fun onLocationResult(r: LocationResult) {
                r.lastLocation?.let {
                    currentLat = it.latitude
                    currentLng = it.longitude
                    tvGpsStatus.text = "📍 GPS: %.5f, %.5f (±${it.accuracy.toInt()}m)".format(it.latitude, it.longitude)
                    updatePreview()
                }
            }
        }, Looper.getMainLooper())
    }

    private fun buildSOSMessage(): String {
        val profile = iceManager.load()
        val name = profile.fullName.ifBlank { "Unknown" }
        val ts = SimpleDateFormat("HH:mm dd/MM/yyyy", Locale.getDefault()).format(Date())
        val parts = mutableListOf<String>()

        if (cbDefaultMsg.isChecked) {
            parts.add("🚨 SOS ALERT 🚨\n$name needs URGENT help!\nTime: $ts")
            if (currentLat != null && currentLng != null) {
                parts.add("📍 GPS: https://www.google.com/maps?q=$currentLat,$currentLng\n($currentLat, $currentLng)")
            } else {
                parts.add("📍 GPS: Unavailable")
            }
            if (profile.bloodType.isNotBlank()) parts.add("🩸 Blood: ${profile.bloodType}")
            parts.add("Local Emergency: 112")
            parts.add("Sent via Global SOS")
        }

        if (cbCustomMsg.isChecked && etCustomMsg.text.isNotBlank()) {
            parts.add(etCustomMsg.text.toString())
        }

        return if (parts.isEmpty()) {
            "🚨 SOS! I need help! — Sent via Global SOS"
        } else parts.joinToString("\n\n")
    }

    private fun updatePreview() {
        val msg = buildSOSMessage()
        tvMsgPreview.text = msg.take(300) + if (msg.length > 300) "..." else ""
    }

    private fun doSystemShare() {
        val msg = buildSOSMessage()
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, msg)
        }
        startActivity(Intent.createChooser(intent, "📤 Send SOS Via..."))
        if (swSiren.isChecked) startSiren()
    }

    private fun doWhatsAppShare() {
        val msg = buildSOSMessage()
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                `package` = "com.whatsapp"
                putExtra(Intent.EXTRA_TEXT, msg)
            }
            startActivity(intent)
        } catch (e: Exception) {
            // WhatsApp not installed, fallback
            val uri = Uri.parse("whatsapp://send?text=${Uri.encode(msg)}")
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (e2: Exception) {
                Toast.makeText(this, "WhatsApp not installed", Toast.LENGTH_SHORT).show()
                doSystemShare()
            }
        }
        if (swSiren.isChecked) startSiren()
    }

    private fun doSmsShare() {
        val contacts = iceManager.getEmergencyContacts()
        if (contacts.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("⚠️ No Emergency Contacts")
                .setMessage("Please add emergency contacts in your ICE Card first.")
                .setPositiveButton("OK", null)
                .show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("🚨 Send SOS SMS")
            .setMessage("Send emergency SMS to ${contacts.size} contact(s)?")
            .setPositiveButton("SEND NOW") { _, _ ->
                val msg = buildSOSMessage()
                contacts.forEach { (_, phone) ->
                    try {
                        val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            getSystemService(SmsManager::class.java)
                        } else {
                            @Suppress("DEPRECATION") SmsManager.getDefault()
                        }
                        val parts = smsManager.divideMessage(msg)
                        smsManager.sendMultipartTextMessage(phone, null, parts, null, null)
                    } catch (e: Exception) {
                        val smsIntent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone"))
                        smsIntent.putExtra("sms_body", msg)
                        startActivity(smsIntent)
                    }
                }
                Toast.makeText(this, "✅ SOS SMS Sent to ${contacts.size} contact(s)!", Toast.LENGTH_LONG).show()
                if (swSiren.isChecked) startSiren()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun doEmergencyCall() {
        AlertDialog.Builder(this)
            .setTitle("📞 Emergency Call")
            .setMessage("Call 112 (International Emergency)?")
            .setPositiveButton("CALL 112") { _, _ ->
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:112"))
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                    startActivity(intent)
                } else {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:112")))
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toggleSiren() {
        val btn = findViewById<Button>(R.id.btnManualSiren)
        if (sirenActive) {
            sirenActive = false
            sirenThread?.interrupt()
            sirenTrack?.apply { try { stop(); release() } catch (e: Exception) {} }
            sirenTrack = null
            btn.text = "🔕 Siren OFF"
        } else {
            btn.text = "🚨 Siren ON — Tap to Stop"
            startSiren(loop = true)
        }
    }

    private fun startSiren(loop: Boolean = false) {
        if (sirenActive && loop) return
        sirenActive = true
        sirenThread = Thread {
            val sampleRate = 44100
            val bufferSize = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            sirenTrack = AudioTrack(AudioManager.STREAM_ALARM, sampleRate, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, bufferSize, AudioTrack.MODE_STREAM)
            sirenTrack?.play()
            val buffer = ShortArray(bufferSize)
            var phase = 0.0; var freq = 450.0; var goingUp = true
            var elapsed = 0; val maxMs = if (loop) Int.MAX_VALUE else 8000
            while (sirenActive && elapsed < maxMs) {
                for (i in buffer.indices) {
                    buffer[i] = (Short.MAX_VALUE * Math.sin(phase)).toInt().toShort()
                    phase += 2.0 * Math.PI * freq / sampleRate
                }
                sirenTrack?.write(buffer, 0, buffer.size)
                if (goingUp) { freq += 5.0; if (freq >= 1300) goingUp = false }
                else { freq -= 5.0; if (freq <= 450) goingUp = true }
                elapsed += (bufferSize * 1000 / sampleRate)
            }
            sirenActive = false
            sirenTrack?.apply { try { stop(); release() } catch (e: Exception) {} }
        }.also { it.start() }
    }

    override fun onDestroy() {
        super.onDestroy()
        sirenActive = false
        sirenThread?.interrupt()
        sirenTrack?.apply { try { stop(); release() } catch (e: Exception) {} }
    }
}
